;+
; FUNCTION: mmo_pwi_efd_calc_pwi2xsm
;
; PURPOSE: to calculate electric field waveform data in MMO_X_SPIN_SUN coordinates from original data.
;
; INPUT:
;   mode: sampling frequency (string)
;   data_pwi: electric field waveform data in PWI cooriates and additional datasets
;
; OUTPUT:
;   result = {x:Ex_xsm_rf, y:Ey_xsm_rf}  
;
;
; Written by: A. Shinbori, Aug 24, 2026
; Modified by:
;   $LastChangedBy:
;   $LastChangedDate:
;   $LastChangedRevision:
;   $URL:
;
;-
function mmo_pwi_efd_calc_pwi2xsm, mode, data_pwi

  ;---Definition of a result array to input calculated data:  
   result = {x:!values.d_nan, y:!values.d_nan}  

  ;--- Reading origianl waveform data --- ; 
   variable = tag_names(data_pwi)
   ep = data_pwi.epoch   
   time_pwi = time_double(ep, /tt2000) 
   md = mode
   fsamp = fix(md)

  ; --- Expand data to timeseries --- ;

   inx = lonarr(2)  
   inx[0] = where(STRMATCH(variable, 'Eu_waveform', /FOLD_CASE) EQ 1)
   inx[1] = where(STRMATCH(variable, 'Ev_waveform', /FOLD_CASE) EQ 1)
   var_wave = variable[inx]
   data_eu = data_pwi.(inx[0])
   data_ev = data_pwi.(inx[1])
  
   inx = where(STRMATCH(variable, 'time_offsets', /FOLD_CASE) EQ 1)
   var_offset = variable[inx]
  
   ti1 = time_pwi
   dt  = data_pwi.time_offsets
   nt  = n_elements(ti1)
   ndt = n_elements(dt)
  
   ndata    = nt*ndt
   time_new = dblarr(ndata)
   sph_new = fltarr(ndata)
  
   for i_ti=0, nt-1 do begin
      time_new[ndt*i_ti:ndt*(i_ti+1)-1] = ti1[i_ti]+dt[*]*1d-3
   endfor

   sph_new = reform(transpose(data_pwi.sph), ndata)
  
   data_Eu_new = reform((data_Eu), ndata)
   data_Eu_new = reform((data_Ev), ndata)

   store_data, var_wave[0], data = {x:time_new, y: data_Eu_new}
   store_data, var_wave[1], data = {x:time_new, y: data_Ev_new}

  ; --- transform the coordinate to XSM in each spin motion  
  ; --- create new data structure--- ;    
   ntime = ndata
   Ex_xsm = replicate(!values.d_nan, (ntime))
   Ey_xsm = replicate(!values.d_nan, (ntime))
    
  ; --- collimation angle of XSM from PWI ---;
   ph0 = 2d0*!pi*(-135.0)/360.0
    
  ; --- initialize the loop for each spin ---;     
    n_sp = fix((time_new[-1]-time_new[0])/data_pwi.spt[0])    
    end_time_E = time_new[-1]

   idx_t = 0
   idx_t_init = idx_t
   for i_ip = 0, n_sp-2L do begin      
      start_time = time_new[idx_t] ; startpoint in iptime
      end_time = double(data_pwi.spt[0]) + start_time      
      idx_st = value_locate(time_new, start_time)
      idx_et = value_locate(time_new, end_time)
      idx_t_init = value_locate(time_new, end_time)    
            
      if start_time gt end_time_E then break
          dph = 2.0*!pi*sph_new[idx_st:idx_et]/360.0 + ph0
          Ex_xsm[idx_t] =   data_Eu_new[idx_t]*cos(dph) + data_Ev_new[idx_t]*sin(dph)
          Ey_xsm[idx_t] = - data_Eu_new[idx_t]*sin(dph) + data_Ev_new[idx_t]*cos(dph) 

      if ((end_time-time_new[0L])/(60d0*60d0) mod 1d0)-((start_time-time_new[0L])/(60d0*60d0) mod 1d0) le 0d0 then print, time_string(end_time);, t2-t1, t3-t2, t4-t3
      idx_t = idx_t_init + 1L 
      if idx_t ge n_elements(Eu_dif) then break 
   endfor

  ; --- store the data ---;   
   data_x = {x:time_new, y:Ex_xsm}
   data_y = {x:time_new, y:Ey_xsm}
   var_wave_ex = 'Ex_waveform_xsm_'+fsamp+'hz'
   var_wave_ey = 'Ey_waveform_xsm_'+fsamp+'hz'
   store_data, var_wave_ex, data = data_x
   store_data, var_wave_ey, data = data_y

  ; --- storing packet data ---;
   print, n_elements(Ex_xsm), fsamp, nt
   Ex_xsm_rf = reform(Ex_xsm, fsamp, nt)
   Ey_xsm_rf = reform(Ey_xsm, fsamp, nt)

   result = {x:Ex_xsm_rf, y:Ey_xsm_rf}  
  
   gt1:
   return, result
  
end
