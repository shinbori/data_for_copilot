#!/usr/bin/env bash

# NASA PDS Validateの実行用配布物をwgetで取得してインストールします。
# 複数のRelease Assetを順番に確認し、bin/validateを含むものだけを採用します。
set -euo pipefail

VERSION="${1:-4.0.8}"
INSTALL_DIR="${2:-$HOME/validate-$VERSION}"
REPOSITORY="NASA-PDS/validate"
API_BASE="https://api.github.com/repos/$REPOSITORY/releases/tags"

for command_name in wget grep sed find java mktemp basename dirname cp chmod; do
  command -v "$command_name" >/dev/null 2>&1 || {
    echo "ERROR: required command not found: $command_name" >&2
    exit 1
  }
done

java -version >/dev/null 2>&1 || {
  echo "ERROR: Java could not be started." >&2
  exit 1
}

TEMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TEMP_DIR"' EXIT
RELEASE_JSON="$TEMP_DIR/release.json"

# v4.0.8、4.0.8の順でRelease情報の取得を試みます。
release_found=0
for tag in "v$VERSION" "$VERSION"; do
  if wget -qO "$RELEASE_JSON" "$API_BASE/$tag" && grep -q 'browser_download_url' "$RELEASE_JSON"; then
    release_found=1
    break
  fi
done

if [[ $release_found -ne 1 ]]; then
  echo "ERROR: GitHub Release was not found for version $VERSION" >&2
  echo "Release page: https://github.com/$REPOSITORY/releases" >&2
  exit 1
fi

# Release AssetのURLを抽出します。
# Source code、文書、チェックサム、署名ファイルは候補から除外します。
grep '"browser_download_url"' "$RELEASE_JSON" \
  | sed -E 's/.*"browser_download_url"[[:space:]]*:[[:space:]]*"([^"]+)".*/\1/' \
  | grep -Ei '\.(tar\.gz|tgz|zip)$' \
  | grep -Evi '(source|sources|src|javadoc|doc|manual|checksum|checksums|sha[0-9]*|signature)' \
  > "$TEMP_DIR/candidates.txt" || true

if [[ ! -s "$TEMP_DIR/candidates.txt" ]]; then
  echo "ERROR: no executable-distribution candidates were found." >&2
  echo "Available asset names:" >&2
  grep '"browser_download_url"' "$RELEASE_JSON" \
    | sed -E 's/.*"browser_download_url"[[:space:]]*:[[:space:]]*"([^"]+)".*/  \1/' >&2 || true
  exit 1
fi

VALIDATE_FILE=""
SOURCE_ROOT=""
SELECTED_URL=""
asset_number=0

# 最初のZIPに決め打ちせず、各候補を確認します。
while IFS= read -r url; do
  asset_number=$((asset_number + 1))
  archive="$TEMP_DIR/asset-$asset_number-$(basename "$url")"
  extract_dir="$TEMP_DIR/extract-$asset_number"
  mkdir -p "$extract_dir"

  echo "Trying asset: $url"
  if ! wget --show-progress -O "$archive" "$url"; then
    echo "WARNING: download failed; trying next asset." >&2
    continue
  fi

  case "$archive" in
    *.tar.gz|*.tgz)
      if ! tar -xzf "$archive" -C "$extract_dir"; then
        echo "WARNING: extraction failed; trying next asset." >&2
        continue
      fi
      ;;
    *.zip)
      command -v unzip >/dev/null 2>&1 || {
        echo "ERROR: unzip is required for ZIP assets." >&2
        exit 1
      }
      if ! unzip -q "$archive" -d "$extract_dir"; then
        echo "WARNING: extraction failed; trying next asset." >&2
        continue
      fi
      ;;
  esac

  # Unix配布物で一般的なbin/validateを検索します。
  VALIDATE_FILE="$(find "$extract_dir" -type f -path '*/bin/validate' -print -quit)"

  # 配布物直下にvalidateがある場合にも対応します。
  if [[ -z "$VALIDATE_FILE" ]]; then
    VALIDATE_FILE="$(find "$extract_dir" -type f -name validate ! -path '*/src/*' -print -quit)"
  fi

  if [[ -n "$VALIDATE_FILE" ]]; then
    SELECTED_URL="$url"
    if [[ "$(basename "$(dirname "$VALIDATE_FILE")")" == "bin" ]]; then
      SOURCE_ROOT="$(cd "$(dirname "$VALIDATE_FILE")/.." && pwd)"
    else
      SOURCE_ROOT="$(dirname "$VALIDATE_FILE")"
    fi
    break
  fi

  echo "WARNING: this asset does not contain bin/validate; trying next asset." >&2
done < "$TEMP_DIR/candidates.txt"

if [[ -z "$VALIDATE_FILE" || -z "$SOURCE_ROOT" ]]; then
  echo "ERROR: none of the Release Assets contained the Unix bin/validate launcher." >&2
  echo "The release may only contain a Windows package or differently structured distribution." >&2
  echo "Candidate assets checked:" >&2
  sed 's/^/  /' "$TEMP_DIR/candidates.txt" >&2
  exit 1
fi

if [[ -e "$INSTALL_DIR" ]]; then
  echo "ERROR: installation directory already exists: $INSTALL_DIR" >&2
  echo "Remove it or pass another directory as the second argument." >&2
  exit 1
fi

mkdir -p "$(dirname "$INSTALL_DIR")"
cp -R "$SOURCE_ROOT" "$INSTALL_DIR"
chmod +x "$INSTALL_DIR/bin/validate"

# 起動確認します。失敗した場合もインストール先を示します。
if ! "$INSTALL_DIR/bin/validate" --help >/dev/null; then
  echo "ERROR: Validate was installed but its launcher failed." >&2
  echo "Check Java and the files under: $INSTALL_DIR" >&2
  exit 1
fi

echo "Selected asset: $SELECTED_URL"
echo "Installed PDS Validate $VERSION to: $INSTALL_DIR"
echo "Executable: $INSTALL_DIR/bin/validate"
