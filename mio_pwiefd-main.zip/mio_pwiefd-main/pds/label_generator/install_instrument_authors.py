#!/usr/bin/env python3
"""Add instrument-specific structured citation authors to the label pipeline."""
from __future__ import annotations
import argparse, ast, shutil
from pathlib import Path

LOAD_FUNCTION='''\n\ndef load_authors(path: Path) -> list[dict[str, str]]:\n    \"\"\"Load and validate an instrument-specific List_Author JSON file.\"\"\"\n    authors_path = path.expanduser().resolve()\n    if not authors_path.is_file():\n        raise FileNotFoundError(f\"Authors file was not found: {authors_path}\")\n    with authors_path.open(\"r\", encoding=\"utf-8\") as stream:\n        authors = json.load(stream)\n    if not isinstance(authors, list) or not authors:\n        raise ValueError(\"The authors file must contain a non-empty JSON list.\")\n    required = (\"display_full_name\", \"given_name\", \"family_name\")\n    normalized = []\n    for index, author in enumerate(authors, start=1):\n        if not isinstance(author, dict):\n            raise ValueError(f\"Author {index} must be a JSON object.\")\n        item = {}\n        for key in required:\n            value = str(author.get(key, \"\")).strip()\n            if not value:\n                raise ValueError(f\"Author {index} is missing a non-empty {key}.\")\n            item[key] = value\n        normalized.append(item)\n    return normalized\n'''

def main():
 p=argparse.ArgumentParser();p.add_argument('--renderer',type=Path,required=True);a=p.parse_args();path=a.renderer.expanduser().resolve()
 text=path.read_text(encoding='utf-8');shutil.copy2(path,path.with_suffix(path.suffix+'.authors.bak'))
 if 'import json\n' not in text:text=text.replace('import hashlib\n','import hashlib\nimport json\n',1)
 if 'def load_authors(' not in text:
  marker='\ndef parse_internal_references('
  if marker not in text:raise RuntimeError('parse_internal_references() was not found')
  text=text.replace(marker,LOAD_FUNCTION+marker,1)
 if '"--authors-file"' not in text:
  marker='    parser.add_argument("--description")\n'
  text=text.replace(marker,marker+'    parser.add_argument(\n        "--authors-file", type=Path, required=True,\n        help="JSON file containing the structured citation author list",\n    )\n',1)
 if 'authors = load_authors(args.authors_file)' not in text:
  marker='    args = build_parser().parse_args()\n'
  if marker not in text:marker='    args = parser.parse_args()\n'
  text=text.replace(marker,marker+'    authors = load_authors(args.authors_file)\n',1)
 text=text.replace('"authors": DEFAULT_AUTHORS,','"authors": authors,')
 ast.parse(text);path.write_text(text,encoding='utf-8',newline='\n');print(f'Updated: {path}');print('Syntax: OK')
if __name__=='__main__':main()
