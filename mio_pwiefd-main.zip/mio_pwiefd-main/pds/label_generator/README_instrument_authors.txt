Instrument-specific List_Author support

1. Copy authors_pwi_efd.json into the label_generator directory.
2. Run install_instrument_authors.py once against render_mmo_cdf_label_multi_dataset.py.
3. Replace the five cron scripts in their original directories.
4. For another instrument, copy authors_instrument_example.json, replace every example value, and set AUTHORS_FILE to that file.
5. The Jinja2 template remains unchanged because it already iterates over the authors list.

All source-code comments added by this package are in English.
