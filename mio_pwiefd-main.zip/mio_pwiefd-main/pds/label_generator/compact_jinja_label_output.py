#!/usr/bin/env python3
"""Compact blank lines in generated PDS4 labels without changing XML content."""

from __future__ import annotations

import argparse
import ast
import re
import shutil
from pathlib import Path


def backup(path: Path) -> Path:
    """Create a backup next to the source file and return its path."""
    backup_path = path.with_suffix(path.suffix + ".before_compact.bak")
    shutil.copy2(path, backup_path)
    return backup_path


def update_template(path: Path) -> None:
    """Enable explicit Jinja whitespace control at the start of the template."""
    text = path.read_text(encoding="utf-8")
    backup_path = backup(path)

    marker = "{%- set _compact_output = true %}"
    if marker not in text:
        # This statement emits no text. Placing it before the XML declaration
        # demonstrates explicit {%- ... %} control without joining XML lines.
        text = marker + "\n" + text

    path.write_text(text, encoding="utf-8", newline="\n")
    print(f"Updated template: {path}")
    print(f"Template backup: {backup_path}")


def update_renderer(path: Path) -> None:
    """Enable Jinja trimming and collapse runs of blank lines after rendering."""
    text = path.read_text(encoding="utf-8")
    backup_path = backup(path)

    # Enable removal of newlines and indentation produced by standalone Jinja
    # block statements such as for, if, else, endif, and endfor.
    text, trim_count = re.subn(
        r"trim_blocks\s*=\s*False",
        "trim_blocks=True",
        text,
        count=1,
    )
    text, lstrip_count = re.subn(
        r"lstrip_blocks\s*=\s*False",
        "lstrip_blocks=True",
        text,
        count=1,
    )

    if trim_count == 0 and "trim_blocks=True" not in text:
        raise RuntimeError("The Jinja Environment trim_blocks setting was not found.")
    if lstrip_count == 0 and "lstrip_blocks=True" not in text:
        raise RuntimeError("The Jinja Environment lstrip_blocks setting was not found.")

    # Replace the direct render-to-write expression with a named rendered
    # value. The regular expression then reduces three or more newline groups
    # to one empty line while retaining XML indentation and comments.
    if "rendered = environment.get_template" not in text:
        old_pattern = re.compile(
            r"(?P<indent>[ \t]*)output\.write_text\(\n"
            r"(?P=indent)[ \t]+environment\.get_template\(template_path\.name\)"
            r"\.render\(\*\*context\),\n"
            r"(?P=indent)[ \t]+encoding=\"utf-8\",\n"
            r"(?P=indent)[ \t]+newline=\"\\n\",\n"
            r"(?P=indent)\)"
        )
        match = old_pattern.search(text)
        if not match:
            raise RuntimeError("The renderer output.write_text block was not found.")

        indent = match.group("indent")
        replacement = (
            f'{indent}# Render first so repeated blank lines can be normalized safely.\n'
            f'{indent}rendered = environment.get_template(\n'
            f'{indent}    template_path.name\n'
            f'{indent}).render(**context)\n\n'
            f'{indent}# Keep at most one empty line between XML sections.\n'
            f'{indent}rendered = re.sub(\n'
            f'{indent}    r"\\n[ \\t]*\\n(?:[ \\t]*\\n)+",\n'
            f'{indent}    "\\n\\n",\n'
            f'{indent}    rendered,\n'
            f'{indent})\n\n'
            f'{indent}output.write_text(\n'
            f'{indent}    rendered,\n'
            f'{indent}    encoding="utf-8",\n'
            f'{indent}    newline="\\n",\n'
            f'{indent})'
        )
        text = text[:match.start()] + replacement + text[match.end():]

    # Parse the complete source to catch indentation or syntax errors before
    # replacing the user's renderer.
    ast.parse(text)
    path.write_text(text, encoding="utf-8", newline="\n")
    print(f"Updated renderer: {path}")
    print(f"Renderer backup: {backup_path}")


def main() -> None:
    """Update one renderer and one Jinja2 template."""
    parser = argparse.ArgumentParser(
        description="Reduce extra blank lines in generated PDS4 labels."
    )
    parser.add_argument("--renderer", required=True, type=Path)
    parser.add_argument("--template", required=True, type=Path)
    args = parser.parse_args()

    renderer = args.renderer.expanduser().resolve()
    template = args.template.expanduser().resolve()

    if not renderer.is_file():
        raise FileNotFoundError(renderer)
    if not template.is_file():
        raise FileNotFoundError(template)

    update_template(template)
    update_renderer(renderer)
    print("Update completed successfully.")


if __name__ == "__main__":
    main()
