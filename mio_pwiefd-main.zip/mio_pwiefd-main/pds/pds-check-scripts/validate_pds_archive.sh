#!/usr/bin/env bash
# Bundle/Collection/DocumentのXML検証と、CDFが存在するLBLX検証を実行します。
set -uo pipefail

BUNDLE_DIR="${1:-/var/www/html/data/chs/satellite/mmo/pds4/bc_mmo_pwi}"
BUNDLE_DIR="${BUNDLE_DIR%/}"
VALIDATE_BIN="${VALIDATE_BIN:-$HOME/validate-4.0.8/bin/validate}"
VALIDATE_CATALOG="${VALIDATE_CATALOG-pds4-validate-catalog.xml}"
REPORT_DIR="${REPORT_DIR:-/home/miosc/mio-sc/work_local/tmp/pds_chk_log}"
TIMESTAMP="${TIMESTAMP:-$(date '+%Y%m%d_%H%M%S')}"
KEEP_STAGE="${KEEP_STAGE:-0}"

BUNDLE_REPORT="$REPORT_DIR/${TIMESTAMP}_bundle_validate_report.txt"
LBLX_REPORT="$REPORT_DIR/${TIMESTAMP}_lblx_validate_report.txt"
SKIP_REPORT="$REPORT_DIR/${TIMESTAMP}_lblx_skipped_missing_cdf.txt"
SUMMARY_REPORT="$REPORT_DIR/${TIMESTAMP}_validation_summary.txt"

[[ -d "$BUNDLE_DIR" ]] || { echo "ERROR: Bundle directory not found: $BUNDLE_DIR" >&2; exit 2; }
[[ -x "$VALIDATE_BIN" ]] || { echo "ERROR: Validate executable not found: $VALIDATE_BIN" >&2; exit 2; }
mkdir -p "$REPORT_DIR"
: > "$SKIP_REPORT"

COMMON_ARGS=()
if [[ -n "$VALIDATE_CATALOG" ]]; then
  if [[ -f "$VALIDATE_CATALOG" ]]; then
    COMMON_ARGS+=(--catalog "$VALIDATE_CATALOG")
  else
    echo "WARNING: XML catalog not found: $VALIDATE_CATALOG" >&2
    echo "WARNING: Continuing without --catalog." >&2
  fi
fi

bundle_rc=0
lblx_rc=0
included=0
skipped=0

# 1. Bundle、Collection、DocumentなどのXMLと参照整合性を一括検証します。
echo "============================================================"
echo "1. Bundle validation"
echo "Target : $BUNDLE_DIR"
echo "Report : $BUNDLE_REPORT"
printf 'Command:'
printf ' %q' "$VALIDATE_BIN" --rule pds4.bundle --target "$BUNDLE_DIR" "${COMMON_ARGS[@]}"
printf '\n'

"$VALIDATE_BIN" \
  --rule pds4.bundle \
  --target "$BUNDLE_DIR" \
  "${COMMON_ARGS[@]}" \
  2>&1 | tee "$BUNDLE_REPORT"
bundle_rc=${PIPESTATUS[0]}

# 2. CDFが存在するLBLXとCDFを一時ディレクトリへリンクします。
STAGE_DIR="$(mktemp -d "${TMPDIR:-/tmp}/pds-lblx-check.XXXXXX")"
cleanup() {
  if [[ "$KEEP_STAGE" == "1" ]]; then
    echo "Staging directory retained: $STAGE_DIR"
  else
    rm -rf "$STAGE_DIR"
  fi
}
trap cleanup EXIT

while IFS= read -r -d '' lblx; do
  source_dir="$(dirname "$lblx")"
  relative_dir="${source_dir#"$BUNDLE_DIR"/}"
  stage_subdir="$STAGE_DIR/$relative_dir"

  mapfile -t cdf_names < <(
    sed -n 's:.*<file_name>[[:space:]]*\([^<]*\.[cC][dD][fF]\)[[:space:]]*</file_name>.*:\1:p' "$lblx"
  )

  missing=0
  for cdf_name in "${cdf_names[@]}"; do
    if [[ ! -f "$source_dir/$cdf_name" ]]; then
      {
        echo "SKIP: $lblx"
        echo "  Missing CDF: $source_dir/$cdf_name"
      } >> "$SKIP_REPORT"
      missing=1
    fi
  done

  if (( missing != 0 )); then
    ((skipped+=1))
    continue
  fi

  mkdir -p "$stage_subdir"
  ln -s "$lblx" "$stage_subdir/$(basename "$lblx")"
  for cdf_name in "${cdf_names[@]}"; do
    ln -s "$source_dir/$cdf_name" "$stage_subdir/$cdf_name"
  done
  ((included+=1))
done < <(
  find "$BUNDLE_DIR" -type f \( -name '*.lblx' -o -name '*.LBLX' \) -print0 | sort -z
)

# 3. LBLXを一括検証します。引数は *.lblx ではなく lblx です。
echo "============================================================"
echo "2. LBLX validation"
echo "Included: $included"
echo "Skipped : $skipped"
echo "Report  : $LBLX_REPORT"

if (( included == 0 )); then
  echo "WARNING: No LBLX labels with available CDF files were found." | tee "$LBLX_REPORT" >&2
  lblx_rc=0
else
  printf 'Command:'
  printf ' %q' "$VALIDATE_BIN" --target "$STAGE_DIR" --label-extension lblx "${COMMON_ARGS[@]}"
  printf '\n'

  "$VALIDATE_BIN" \
    --target "$STAGE_DIR" \
    --label-extension lblx \
    "${COMMON_ARGS[@]}" \
    2>&1 | tee "$LBLX_REPORT"
  lblx_rc=${PIPESTATUS[0]}
fi

# 4. 全体結果を保存します。
overall_rc=0
(( bundle_rc == 0 )) || overall_rc=1
(( lblx_rc == 0 )) || overall_rc=1

{
  echo "PDS4 validation summary"
  echo "Timestamp    : $TIMESTAMP"
  echo "Bundle       : $BUNDLE_DIR"
  echo "Bundle result: $([[ $bundle_rc -eq 0 ]] && echo PASS || echo FAIL)"
  echo "LBLX result  : $([[ $lblx_rc -eq 0 ]] && echo PASS || echo FAIL)"
  echo "LBLX included: $included"
  echo "LBLX skipped : $skipped"
  echo "Bundle report: $BUNDLE_REPORT"
  echo "LBLX report  : $LBLX_REPORT"
  echo "Skip report  : $SKIP_REPORT"
  echo "Overall      : $([[ $overall_rc -eq 0 ]] && echo PASS || echo FAIL)"
} | tee "$SUMMARY_REPORT"

exit "$overall_rc"
