# PDS4 Archive Validation Script

`validate_pds_archive.sh` は、BepiColombo MMO PWI のPDS4 Bundleを対象に、Bundle全体、XMLラベル、LBLXラベルを順番に検証し、各レポートを一つのディレクトリへ保存するスクリプトです。

## ファイル

```text
pds-check-scripts/
├── README.md
└── validate_pds_archive.sh
```

## 検証内容

スクリプトは次の順序で検証します。

1. Bundle全体を `pds4.bundle` ルールで検証
2. Bundle配下の `.xml` および `.XML` ラベルを個別検証
3. Bundle配下の `.lblx` および `.LBLX` ラベルを個別検証
4. PASS件数、FAIL件数、全体結果をサマリーレポートへ保存

## 前提条件

- Bashが利用できること
- PDS Validate Tool 4.0.8がインストールされていること
- 既定では、Validate Toolが次に存在すること

```text
$HOME/validate-4.0.8/bin/validate
```

- 検証対象Bundleが次に存在すること

```text
/var/www/html/data/chs/satellite/mmo/pds4/bc_mmo_pwi
```

## 配置

```bash
CHECK_DIR="/home/miosc/mio-sc/work_local/data_pipeline/mmo/pwi/efd/pds/pds-check-scripts"

mkdir -p "$CHECK_DIR"
cp validate_pds_archive.sh "$CHECK_DIR/"
cp README.md "$CHECK_DIR/"
chmod +x "$CHECK_DIR/validate_pds_archive.sh"
```

## 基本的な実行方法

```bash
cd /home/miosc/mio-sc/work_local/data_pipeline/mmo/pwi/efd/pds/pds-check-scripts

./validate_pds_archive.sh \
  /var/www/html/data/chs/satellite/mmo/pds4/bc_mmo_pwi
```

引数を省略した場合は、既定のBundleディレクトリを使用します。

```bash
./validate_pds_archive.sh
```

## レポート保存先

既定の保存先は次です。

```text
/home/miosc/mio-sc/work_local/tmp/pds_chk_log
```

保存先が存在しない場合は自動的に作成されます。

レポート名には実行日時、検証カテゴリ、対象名が含まれます。

```text
20260909_130000_bundle_bc_mmo_pwi.txt
20260909_130000_xml_bundle.xml.txt
20260909_130000_xml_data_calibrated_efd_data_calibrated_efd.xml.txt
20260909_130000_lblx_data_calibrated_efd_science_product.lblx.txt
20260909_130000_summary.txt
```

## レポート保存先の変更

環境変数 `REPORT_DIR` で変更できます。

```bash
REPORT_DIR="/任意のログディレクトリ" \
./validate_pds_archive.sh \
  /var/www/html/data/chs/satellite/mmo/pds4/bc_mmo_pwi
```

## Validate Toolのパス変更

環境変数 `VALIDATE_BIN` で変更できます。

```bash
VALIDATE_BIN="/任意のパス/validate" \
./validate_pds_archive.sh \
  /var/www/html/data/chs/satellite/mmo/pds4/bc_mmo_pwi
```

## XML Catalog

既定では、カレントディレクトリの次のCatalogを確認します。

```text
pds4-validate-catalog.xml
```

Catalogが存在する場合は `--catalog` を付けて検証します。存在しない場合は警告を表示し、Catalogなしで続行します。

Catalogを明示的に無効化する場合:

```bash
VALIDATE_CATALOG="" \
./validate_pds_archive.sh \
  /var/www/html/data/chs/satellite/mmo/pds4/bc_mmo_pwi
```

Catalogをフルパスで指定する場合:

```bash
VALIDATE_CATALOG="/任意のパス/pds4-validate-catalog.xml" \
./validate_pds_archive.sh \
  /var/www/html/data/chs/satellite/mmo/pds4/bc_mmo_pwi
```

## 特定の実行日時文字列を使用する場合

テストや再現性確保のため、`TIMESTAMP` を指定できます。

```bash
TIMESTAMP="20260909_130000" \
./validate_pds_archive.sh \
  /var/www/html/data/chs/satellite/mmo/pds4/bc_mmo_pwi
```

同じ `TIMESTAMP` を再利用すると、同名レポートが上書きされる点に注意してください。

## 終了コード

```text
0  すべての検証がPASS
1  1件以上の検証がFAIL
2  BundleディレクトリまたはValidate実行ファイルが見つからない
```

## サマリーレポート

実行後、次の形式のサマリーが保存されます。

```text
PDS4 validation summary
Timestamp : 20260909_130000
Bundle    : /var/www/html/data/chs/satellite/mmo/pds4/bc_mmo_pwi
Validate  : /home/miosc/mio-sc/validate-4.0.8/bin/validate
Report dir: /home/miosc/mio-sc/work_local/tmp/pds_chk_log
Passed    : 134
Failed    : 0
Skipped   : 0
Result    : PASS
```

件数は実際の検証対象と結果によって変わります。

## 実行例

### 標準実行

```bash
./validate_pds_archive.sh
```

### Bundleパスを指定

```bash
./validate_pds_archive.sh \
  /var/www/html/data/chs/satellite/mmo/pds4/bc_mmo_pwi
```

### Catalogなしで実行

```bash
VALIDATE_CATALOG="" ./validate_pds_archive.sh
```

### ログ保存先を変更

```bash
REPORT_DIR="$HOME/pds-validation-logs" \
./validate_pds_archive.sh
```

## 注意事項

- Bundleディレクトリ検証では、既定のファイルフィルターによりXMLラベルが処理されます。
- `.lblx`ラベルは `find` で検索し、各ファイルを `--target` に指定して個別検証します。
- 個別検証に失敗しても、スクリプトは残りのラベルを続けて検証します。
- 最後にFAIL件数が1件以上あれば、スクリプト全体の終了コードは1になります。
- レポートにはValidate Toolの標準出力と標準エラーの両方が保存されます。
