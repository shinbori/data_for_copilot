#!/usr/bin/env bash
#
# Generate and validate a PSA/PDS4 Collection label and inventory file.
#
# Usage:
#   create_psa_collection_jinja.sh [COLLECTION_NAME] [COLLECTION_DIR]
#
# Example:
#   create_psa_collection_jinja.sh \
#       data_calibrated_efd \
#       bc_mmo_pwi/data_calibrated_efd
#
# Default outputs:
#   collection_data_calibrated_efd.xml
#   collection_data_calibrated_efd.csv
#
set -euo pipefail

# The renderer and template are expected in the same directory as this script.
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"

# The first argument specifies the Collection name.
COLLECTION_NAME="${1:-data_calibrated_efd}"

# The second argument specifies the Collection directory.
COLLECTION_DIR="${2:-bc_mmo_pwi/${COLLECTION_NAME}}"
COLLECTION_DIR="${COLLECTION_DIR%/}"

# Bundle and Collection metadata.
BUNDLE_NAME="${BUNDLE_NAME:-bc_mmo_pwi}"
LABEL_DIR="${LABEL_DIR:-${COLLECTION_DIR}/science}"
COLLECTION_LID="${COLLECTION_LID:-urn:jaxa:darts:${BUNDLE_NAME}:${COLLECTION_NAME}}"

# Prefix the generated XML and CSV file names with "collection_".
# Example:
#   COLLECTION_NAME=data_calibrated_efd
#   OUTPUT_BASE=collection_data_calibrated_efd
#
# OUTPUT_BASE can still be overridden explicitly with an environment variable.
OUTPUT_BASE="${OUTPUT_BASE:-collection_${COLLECTION_NAME}}"

# Generator resources located alongside this script.
TEMPLATE_FILE="${TEMPLATE_FILE:-${SCRIPT_DIR}/collection_template.xml.j2}"
RENDERER_FILE="${RENDERER_FILE:-${SCRIPT_DIR}/render_psa_collection.py}"

# PDS Validate settings.
VALIDATE_ENABLED="${VALIDATE_ENABLED:-1}"
VALIDATE_BIN="${VALIDATE_BIN:-${HOME}/validate-4.0.8/bin/validate}"
VALIDATE_CATALOG="${VALIDATE_CATALOG-pds4-validate-catalog.xml}"

# Shared storage location for validation reports.
REPORT_DIR="${REPORT_DIR:-/srv/storage/work/mio-sc/tmp/pds_chk_log}"
REPORT_TIMESTAMP="${REPORT_TIMESTAMP:-$(date '+%Y%m%d_%H%M%S')}"
VALIDATE_REPORT="${VALIDATE_REPORT:-${REPORT_DIR}/${REPORT_TIMESTAMP}_${OUTPUT_BASE}_validate_report.txt}"

# Collection names may contain letters, numbers, underscores, and hyphens.
case "${COLLECTION_NAME}" in
    *[!A-Za-z0-9_-]*|'')
        echo "ERROR: Invalid Collection name: ${COLLECTION_NAME}" >&2
        exit 1
        ;;
esac

# Verify required directories, files, and commands before generation.
[[ -d "${COLLECTION_DIR}" ]] || {
    echo "ERROR: Collection directory not found: ${COLLECTION_DIR}" >&2
    exit 1
}

[[ -d "${LABEL_DIR}" ]] || {
    echo "ERROR: Label directory not found: ${LABEL_DIR}" >&2
    exit 1
}

[[ -f "${TEMPLATE_FILE}" ]] || {
    echo "ERROR: Template file not found: ${TEMPLATE_FILE}" >&2
    exit 1
}

[[ -f "${RENDERER_FILE}" ]] || {
    echo "ERROR: Renderer not found: ${RENDERER_FILE}" >&2
    exit 1
}

command -v python3 >/dev/null 2>&1 || {
    echo "ERROR: python3 was not found." >&2
    exit 1
}

python3 -c 'import jinja2' >/dev/null 2>&1 || {
    echo "ERROR: Jinja2 is required." >&2
    exit 1
}

# Build a human-readable data collection name from COLLECTION_NAME.
# Examples:
#   data_calibrated_sorbet -> SORBET
#   data_calibrated_efd    -> EFD
COLLECTION_DATA_NAME="${COLLECTION_NAME}"
COLLECTION_DATA_NAME="${COLLECTION_DATA_NAME#data_raw_}"
COLLECTION_DATA_NAME="${COLLECTION_DATA_NAME#data_partial_}"
COLLECTION_DATA_NAME="${COLLECTION_DATA_NAME#data_calibrated_}"
COLLECTION_DATA_NAME="${COLLECTION_DATA_NAME#data_derived_}"
COLLECTION_DATA_NAME="${COLLECTION_DATA_NAME^^}"
COLLECTION_DESCRIPTION="This collection contains BepiColombo Mio Plasma Wave Investigation products for the ${COLLECTION_DATA_NAME} data collection."

# Read list_author or legacy author_list from observational labels.
# Duplicate values are removed while preserving first-seen order.
LIST_AUTHOR="$(python3 - "${COLLECTION_DIR}" <<'PY_AUTHOR'
from pathlib import Path
from xml.etree import ElementTree as ET
import sys

collection_dir = Path(sys.argv[1])
authors = []
seen = set()
parsed_labels = 0

def local_name(tag: str) -> str:
    """Return an XML element name without its namespace."""
    return tag.rsplit("}", 1)[-1].lower().replace("-", "_")

def add_author(value: str) -> None:
    """Normalize and add an author value once."""
    value = " ".join(value.split())
    if value and value not in seen:
        seen.add(value)
        authors.append(value)

# Search the entire Collection tree because labels may be below science/year
# directories or directly below the Collection directory.
for label_path in sorted(collection_dir.rglob("*")):
    if not label_path.is_file() or label_path.suffix.lower() not in {".xml", ".lblx"}:
        continue

    try:
        root = ET.parse(label_path).getroot()
    except (ET.ParseError, OSError):
        continue

    parsed_labels += 1

    for element in root.iter():
        name = local_name(element.tag)

        # Legacy/simple forms:
        #   <author_list>...</author_list>
        #   <list_author>...</list_author>
        #   <list-author>...</list-author>
        if name in {"author_list", "list_author"} and element.text:
            add_author(element.text)
            continue

        # Structured Author_List forms used by newer labels. Accept common
        # child element names without depending on a specific namespace.
        if name in {
            "author_name",
            "full_name",
            "individual_name",
            "person_name",
        } and element.text:
            parent_is_author_list = any(
                local_name(parent.tag) in {"author_list", "list_author"}
                and element in list(parent)
                for parent in root.iter()
            )
            if parent_is_author_list:
                add_author(element.text)

if not authors:
    print(
        f"ERROR: No author metadata found in {parsed_labels} parsed label(s) "
        f"under {collection_dir}",
        file=sys.stderr,
    )
    raise SystemExit(2)

print(", ".join(authors))
PY_AUTHOR
)"

if [[ -z "${LIST_AUTHOR}" ]]; then
    echo "ERROR: Author metadata could not be collected under: ${COLLECTION_DIR}" >&2
    exit 1
fi

# Create the validation report directory before generation.
mkdir -p "${REPORT_DIR}"
mkdir -p "$(dirname "${VALIDATE_REPORT}")"

echo "Collection name : ${COLLECTION_NAME}"
echo "Collection dir  : ${COLLECTION_DIR}"
echo "Label dir       : ${LABEL_DIR}"
echo "Bundle name     : ${BUNDLE_NAME}"
echo "Collection LID  : ${COLLECTION_LID}"
echo "Data name       : ${COLLECTION_DATA_NAME}"
echo "Description     : ${COLLECTION_DESCRIPTION}"
echo "List author     : ${LIST_AUTHOR}"
echo "Output base     : ${OUTPUT_BASE}"
echo "Output XML      : ${COLLECTION_DIR}/${OUTPUT_BASE}.xml"
echo "Output CSV      : ${COLLECTION_DIR}/${OUTPUT_BASE}.csv"
echo "Report dir      : ${REPORT_DIR}"
echo "Report file     : ${VALIDATE_REPORT}"

# Generate the Collection XML label and inventory CSV.
COLLECTION_DATA_NAME="${COLLECTION_DATA_NAME}" \
COLLECTION_DESCRIPTION="${COLLECTION_DESCRIPTION}" \
LIST_AUTHOR="${LIST_AUTHOR}" \
python3 "${RENDERER_FILE}" \
    "${LABEL_DIR}" \
    "${COLLECTION_DIR}" \
    "${TEMPLATE_FILE}" \
    "${COLLECTION_LID}" \
    "${OUTPUT_BASE}"

# Move the missing-CDF report out of the archive Collection directory and into
# the shared report directory. The renderer is expected to create this report
# beside the Collection XML and CSV files when one or more CDF files are absent.
SKIPPED_REPORT_NAME="${OUTPUT_BASE}_skipped_missing_cdf.txt"
SKIPPED_REPORT_SOURCE="${COLLECTION_DIR}/${SKIPPED_REPORT_NAME}"
SKIPPED_REPORT_DESTINATION="${REPORT_DIR}/${SKIPPED_REPORT_NAME}"

if [[ -f "${SKIPPED_REPORT_SOURCE}" ]]; then
    mv -f "${SKIPPED_REPORT_SOURCE}" "${SKIPPED_REPORT_DESTINATION}"
    echo "Missing-CDF report: ${SKIPPED_REPORT_DESTINATION}"
elif [[ -f "${SKIPPED_REPORT_DESTINATION}" ]]; then
    echo "Missing-CDF report: ${SKIPPED_REPORT_DESTINATION}"
else
    echo "Missing-CDF report: not generated"
fi

# Confirm that both expected Collection files were generated.
COLLECTION_XML="${COLLECTION_DIR}/${OUTPUT_BASE}.xml"
COLLECTION_CSV="${COLLECTION_DIR}/${OUTPUT_BASE}.csv"

[[ -f "${COLLECTION_XML}" ]] || {
    echo "ERROR: Generated Collection XML not found: ${COLLECTION_XML}" >&2
    exit 1
}

[[ -f "${COLLECTION_CSV}" ]] || {
    echo "ERROR: Generated Collection CSV not found: ${COLLECTION_CSV}" >&2
    exit 1
}

# Allow generation without validation when explicitly requested.
if [[ "${VALIDATE_ENABLED}" == "0" ]]; then
    echo "Validation skipped because VALIDATE_ENABLED=0"
    exit 0
fi

[[ -x "${VALIDATE_BIN}" ]] || {
    echo "ERROR: Validate executable not found or not executable: ${VALIDATE_BIN}" >&2
    exit 1
}

VALIDATE_ARGS=(
    --target "${COLLECTION_XML}"
)

# Use the XML catalog only when it exists.
if [[ -n "${VALIDATE_CATALOG}" ]]; then
    if [[ -f "${VALIDATE_CATALOG}" ]]; then
        VALIDATE_ARGS+=(--catalog "${VALIDATE_CATALOG}")
        echo "Using XML catalog: ${VALIDATE_CATALOG}"
    else
        echo "WARNING: XML catalog was not found: ${VALIDATE_CATALOG}" >&2
        echo "WARNING: Validation will continue without --catalog." >&2
    fi
else
    echo "XML catalog is not specified."
    echo "Validation will continue without --catalog."
fi

echo "Validating Collection label: ${COLLECTION_XML}"
echo "Validation report: ${VALIDATE_REPORT}"
printf 'Validation command:'
printf ' %q' "${VALIDATE_BIN}" "${VALIDATE_ARGS[@]}"
printf '\n'

"${VALIDATE_BIN}" "${VALIDATE_ARGS[@]}" 2>&1 | tee "${VALIDATE_REPORT}"

echo "Collection label validation passed."
echo "Validation report saved to: ${VALIDATE_REPORT}"
