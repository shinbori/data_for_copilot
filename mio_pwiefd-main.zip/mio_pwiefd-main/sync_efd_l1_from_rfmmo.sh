#!/bin/bash
#
# ----------------------------------------------------------------------------------- #
#  SYNC_EFD_L1_FROM_RFMMO for Mio SC ver 1.00
#  Released on 2024.03.06, ISEE, A.SHINBORI
# ----------------------------------------------------------------------------------- #
#  -- INTRODUCTION --
#
#  -- HOW TO RUN --
#     -- FOR ALL DATA --
#  nice ./sync_efd_l1_from_rfmmo.sh
#  -- FOR the DATA CORRESPONDING TO GIVEN MUTIPLE DATES--
#  nice ./sync_efd_l1_from_rfmmo.sh 20180316 ...
#
#  -- DATA LOCATION --
# src: rfmmo:/nasA_mmo/pwi/cdf/EFD/L1/2018/bc_mmo_pwi-efd_l1_E_L_20180316_r01_v01_00.cdf
# dest: mio-sc@chs01:~/work/data_org/bc/mmo/pwi/efd/l1/2018/bc_mmo_pwi-efd_l1_E_L_20180316_r01_v01_00.cdf
#
#  -- YOU CAN DO NEXT --
#
# ----------------------------------------------------------------------------------- #
#

#### Suppress duplicated runs ####
CMDLINE=$(cat /proc/$$/cmdline | xargs --null)
if [[ $$ -ne $(pgrep -oxf "${CMDLINE}") ]]; then
  #echo "Already running!" >&2
  exit 9 >/dev/null 2>&1
fi

#### Define data paths ####
LOCALDIR=~/work_local/data_org/bc/mmo/pwi/efd/l1
REMOTEDIR="mio-sc@rfmmo:/nasA_mmo/pwi/cdf/EFD/L1"
echo "LOCALDIR for data:  "${LOCALDIR}
echo "REMOTEDIR for data: "${REMOTEDIR}

#### Create the directory to store data on the local data server if there is no local directory #### 
[ ! -d ${LOCALDIR} ] && mkdir -p ${LOCALDIR}   

#### Set the cmd path ####
source ~/.bash_path

#### Copy efd l1 CDF data from rfmmo to chs01 ####
### For all data ####
if [ $# -lt 1 ]; then
    
    echo "Run w/o argument: the entire data directories are sync'd"
    date
    nice -n 19 rsync --rsync-path="nice -n 8 rsync" -auv --progress ${REMOTEDIR}/ ${LOCALDIR}/

### For the data corresponding to given multiple dates ####    
else 
    echo "Data files for designated dates are sync'd"
    remotedir=${REMOTEDIR}
    localdir=${LOCALDIR}
    prefix="bc_mmo_pwi-efd_l1-"
    echo "localdir = "${localdir}
    nice -n 19 rsync -au --list-only --rsync-path="nice -n 8 rsync" --include='bc_mmo_pwi-efd_l1-*.cdf' --exclude='*' ${remotedir}/ ${localdir}/ | grep ${prefix} | awk '{print $5}' > flist.$$
    
    echo -n "" > flist.txt.$$
    for ymd in $* ; do
	echo ${ymd}
	cat flist.$$ | grep "${ymd}" >>flist.txt.$$ 2>/dev/null
    done
    
    date
    nice -n 19 rsync --rsync-path="nice -n 8 rsync" -auv --progress --files-from flist.txt.$$ ${remotedir}/ ${localdir}/ 
    
    /bin/rm -f flist.$$ flist.txt.$$
fi

echo $0" ended normally"
date

exit 0
