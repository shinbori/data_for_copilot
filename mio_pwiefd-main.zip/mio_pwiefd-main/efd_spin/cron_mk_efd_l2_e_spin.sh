#!/usr/bin/env bash
#
# Usage:
#   cron_mk_efd_l2_e_spin.sh
#   cron_mk_efd_l2_e_spin.sh all
#

set -u
shopt -s nullglob

LOCKFILE="/tmp/$(basename "$0").lock"

exec 9>"$LOCKFILE"
flock -n 9 || {
    echo "Already running: $0" >&2
    exit 9
}

date

export PYTHONPATH="${HOME}/work_local/pds_pipeline/common/miopds_common"

WDIR="${HOME}/work_local/data_pipeline/mmo/pwi/efd/efd_spin"
L1_PRIMEPATH="${HOME}/work_local/data_org/bc/mmo/pwi/efd/l1_prime"
L2_BASE="${HOME}/work_local/mmodata/cdf/pwi/efd/l2"

LABEL_GENERATOR_DIR="${HOME}/work_local/data_pipeline/mmo/pwi/efd/pds/label_generator"
TEMPLATEPATH="${TEMPLATEPATH:-$LABEL_GENERATOR_DIR}"
TEMPLATE_NAME="${TEMPLATE_NAME:-mmo_cdf_label_template_multi_dataset.xml.j2}"
TEMPLATE_FILE="${TEMPLATEPATH}/${TEMPLATE_NAME}"
LABEL_GENERATOR="${LABEL_GENERATOR:-${LABEL_GENERATOR_DIR}/make_pds_label_for_mmo_cdf_data.sh}"
PDS_SCIENCE_BASE="${PDS_SCIENCE_BASE:-/var/www/html/data/chs/satellite/mmo/pds4/bc_mmo_pwi/data_calibrated_efd/science}"

# Configure the shared label renderer and instrument-specific author list.
LABEL_PROFILE="${LABEL_PROFILE:-pwi-efd}"
MISSION_PHASE_NAME="${MISSION_PHASE_NAME:-Cruise}"
MISSION_PHASE_ID="${MISSION_PHASE_ID:-cruise}"
AUTHORS_FILE="${AUTHORS_FILE:-${LABEL_GENERATOR_DIR}/authors_pwi_efd.json}"

# Document-product references.
PWI_USER_GUIDE_LIDVID="${PWI_USER_GUIDE_LIDVID:-urn:jaxa:darts:bc_mmo_pwi:document:pwi_data_user_guide::1.0}"
PWI_CALIBRATION_GUIDE_LIDVID="${PWI_CALIBRATION_GUIDE_LIDVID:-urn:jaxa:darts:bc_mmo_pwi:document:pwi_efd_calibration_guide::1.0}"

# SPICE Kernel-product references.
# Set these to registered PSA/PDS4 LIDVID values before archive delivery.
BC_MMO_LSK_LIDVID="${BC_MMO_LSK_LIDVID:-urn:esa:psa:bc_spice:spice_kernels:lsk_naif0012.tls::1.0}"
BC_MMO_SCLK_LIDVID="${BC_MMO_SCLK_LIDVID:-urn:esa:psa:bc_spice:spice_kernels:sclk:bc_mmo_stre_20250305_v01.tsc::1.0}"
BC_MMO_FK_LIDVID="${BC_MMO_FK_LIDVID:-urn:esa:psa:bc_spice:spice_kernels:fk_bc_mmo_v14.tf::1.0}"

# Map the L1p filename version to the PDS VID used by the archived product.
l1_filename_version_to_pds_vid()
{
    local filename_version="$1"

    case "$filename_version" in
        r01-v00-00|r01-v01-00|r02-v01-00)
            printf '%s\n' "1.0"
            ;;
        *)
            echo "ERROR: No PDS VID mapping for L1p version: $filename_version" >&2
            return 1
            ;;
    esac
}

L1_PRIMEVER="r01-v00-00"
L2VER="r01-v00-00"
MIN_DATE="20181001"

cd "$WDIR" || {
    echo "ERROR: Cannot change directory: $WDIR" >&2
    exit 1
}
[[ -x "$LABEL_GENERATOR" ]] || { echo "ERROR: Label generator is not executable: $LABEL_GENERATOR" >&2; exit 1; }
[[ -f "$TEMPLATE_FILE" ]] || { echo "ERROR: Label template not found: $TEMPLATE_FILE" >&2; exit 1; }
[[ -f "$AUTHORS_FILE" ]] || {
    echo "ERROR: Citation authors file was not found: $AUTHORS_FILE" >&2
    exit 1
}

mkdir -p "$PDS_SCIENCE_BASE"

ALL_UPDATE=0

case "${1:-}" in
    "")
        ;;
    all)
        ALL_UPDATE=1
        ;;
    *)
        echo "Usage: $(basename "$0") [all]" >&2
        exit 2
        ;;
esac

process_mode()
{
    local mode="$1"
    local cdf_script_name="$2"

    local l2_path="${L2_BASE}/${mode}/e_spin"
    local cdf_script="${WDIR}/${cdf_script_name}"

    local input_file
    local input_name
    local ymd
    local yyyy
    local mm
    local cdf_dir
    local cdf_file
    local label_dir
    local pds_cdf
    local pds_cdf
    local label_file

    local result=0
    local reference l1_filename_version l1_pds_vid raw_lidvid
    local -a internal_references=()
    local -a reference_args=()

    echo
    echo "============================================================"
    echo "Processing ${mode^^}-mode E-spin data"
    echo "============================================================"

    echo "L1 prime directory: $L1_PRIMEPATH"
    echo "Search pattern:"
    echo "  ${L1_PRIMEPATH}/????/bc_mmo_pwi-efd_l1p_${mode}-e_????????_r??-v??-??.cdf"

    if [[ ! -d "$L1_PRIMEPATH" ]]; then
        echo "ERROR: L1 prime directory not found:" >&2
        echo "       $L1_PRIMEPATH" >&2
        return 1
    fi

    if [[ ! -x "$cdf_script" ]]; then
        echo "ERROR: CDF generator is not executable:" >&2
        echo "       $cdf_script" >&2
        return 1
    fi

    # 入力検索ではバージョンを固定しない
    local -a all_input_files=(
        "${L1_PRIMEPATH}"/????/bc_mmo_pwi-efd_l1p_"${mode}"-e_????????_r??-v??-??.cdf
    )

    echo "Number of matching input files: ${#all_input_files[@]}"

    if (( ${#all_input_files[@]} == 0 )); then
        echo "WARNING: No input files found for ${mode^^}-mode." >&2
        echo "Files currently present under L1 prime:" >&2

        find "$L1_PRIMEPATH" \
            -maxdepth 2 \
            -type f \
            -name "*${mode}-e*.cdf" \
            -print \
            | head -20 >&2

        return 0
    fi

    # ファイル名から日付を集める
    local -A dates=()

    for input_file in "${all_input_files[@]}"; do
        input_name=${input_file##*/}

        ymd=${input_name#bc_mmo_pwi-efd_l1p_${mode}-e_}
        ymd=${ymd%%_*}

        if [[ $ymd =~ ^[0-9]{8}$ ]]; then
            dates["$ymd"]=1
        else
            echo "WARNING: Cannot extract date: $input_file" >&2
        fi
    done

    echo "Number of target dates: ${#dates[@]}"

    if (( ${#dates[@]} == 0 )); then
        echo "WARNING: No valid dates were found for ${mode^^}-mode." >&2
        return 0
    fi

    while IFS= read -r ymd; do
        (( 10#$ymd >= 10#$MIN_DATE )) || continue

        # Derive the exact source-product reference from the input filename.
        if [[ "$input_name" =~ _(r[0-9]+-v[0-9]+-[0-9]+)\.cdf$ ]]; then
            l1_filename_version="${BASH_REMATCH[1]}"
        else
            echo "WARNING: Cannot extract the L1p version: $input_file" >&2
            continue
        fi
        l1_pds_vid="$(l1_filename_version_to_pds_vid "$l1_filename_version")" || continue
        raw_lidvid="urn:jaxa:darts:bc_mmo_pwi:data_raw_efd:bc-mmo-pwi_raw_sc_efd_l1p_${mode}-e_${ymd}::${l1_pds_vid}"
        internal_references=(
            "${PWI_USER_GUIDE_LIDVID}|data_to_document"
            "${PWI_CALIBRATION_GUIDE_LIDVID}|data_to_document"
            "${BC_MMO_LSK_LIDVID}|data_to_spice_kernel"
            "${BC_MMO_SCLK_LIDVID}|data_to_spice_kernel"
            "${BC_MMO_FK_LIDVID}|data_to_spice_kernel"
            "${raw_lidvid}|data_to_raw_product"
        )

        yyyy=${ymd:0:4}
        mm=${ymd:4:2}

        # 指定バージョンを優先
        input_file="${L1_PRIMEPATH}/${yyyy}/bc_mmo_pwi-efd_l1p_${mode}-e_${ymd}_${L1_PRIMEVER}.cdf"

        # 指定バージョンがなければ、その日付の最新候補を使う
        if [[ ! -f "$input_file" ]]; then
            local -a candidates=(
                "${L1_PRIMEPATH}/${yyyy}/bc_mmo_pwi-efd_l1p_${mode}-e_${ymd}_"r??-v??-??.cdf
            )

            if (( ${#candidates[@]} == 0 )); then
                echo "WARNING: No input CDF found for $ymd" >&2
                result=1
                continue
            fi

            input_file=$(
                printf '%s\n' "${candidates[@]}" |
                    sort -V |
                    tail -1
            )

            echo "WARNING: Requested version not found: $L1_PRIMEVER" >&2
            echo "         Using: $(basename "$input_file")" >&2
        fi

        cdf_dir="${l2_path}/${yyyy}/${mm}"
        cdf_file="${cdf_dir}/bc_mmo_pwi-efd_l2_${mode}-e-spin_${ymd}_${L2VER}.cdf"

        label_dir="${PDS_SCIENCE_BASE}/${yyyy}0101_${yyyy}1231"
        pds_cdf="${label_dir}/$(basename "$cdf_file")"

        # 現在のPythonがCDF名の末尾.cdfを.lblxへ変換する場合
        label_file="${label_dir}/$(basename "${cdf_file%.cdf}").lblx"

        mkdir -p "$cdf_dir" "$label_dir" || {
            echo "ERROR: Cannot create output directories." >&2
            result=1
            continue
        }

        echo
        echo "Processing date : $ymd"
        echo "L1 source file  : $input_file"
        echo "L2 target file  : $cdf_file"
        echo "Label target    : $label_file"

        if (( ALL_UPDATE )); then
            rm -f "$cdf_file" "$pds_cdf" "$label_file"
        fi

        if [[ ! -f "$cdf_file" || "$input_file" -nt "$cdf_file" ]]; then
            echo "Running CDF generator:"
            echo "  $cdf_script -v $L2VER $ymd"

            if ! "$cdf_script" -v "$L2VER" "$ymd"; then
                echo "ERROR: CDF generation failed: $ymd" >&2
                result=1
                continue
            fi
        else
            echo "CDF is up to date."
        fi

        if [[ ! -f "$cdf_file" ]]; then
            echo "ERROR: Expected CDF was not generated:" >&2
            echo "       $cdf_file" >&2
            echo "CDF files actually present:" >&2

            find "$cdf_dir" \
                -maxdepth 1 \
                -type f \
                -name "*${ymd}*.cdf" \
                -print >&2

            result=1
            continue
        fi

        # Copy the generated CDF to the year-specific PDS4 science directory.
        echo "CDF copy source   : $cdf_file"
        echo "CDF copy target   : $pds_cdf"
        if [[ ! -f "$pds_cdf" || "$cdf_file" -nt "$pds_cdf" ]]; then
            if ! cp -fp "$cdf_file" "$pds_cdf"; then
                echo "ERROR: Failed to copy CDF to PDS4 directory: $cdf_file" >&2
                result=1
                continue
            fi
        else
            echo "PDS4 CDF copy is up to date."
        fi
        [[ -f "$pds_cdf" ]] || { echo "ERROR: Copied CDF does not exist: $pds_cdf" >&2; result=1; continue; }
        echo "Running PDS label generator:"
        echo "  CDF file : $pds_cdf"
        echo "  Template : $TEMPLATE_FILE"
        echo "  Output   : $label_dir"
        reference_args=()
        for reference in "${internal_references[@]}"; do
            reference_args+=(--internal-reference "$reference")
        done

        if ! "$LABEL_GENERATOR" \
            "$pds_cdf" \
            "$TEMPLATEPATH" \
            "$TEMPLATE_NAME" \
            "$label_dir" \
            --profile "$LABEL_PROFILE" \
            --time-variable strtime \
            --epoch-variable epoch \
            --mission-phase-name "$MISSION_PHASE_NAME" \
            --mission-phase-id "$MISSION_PHASE_ID" \
            --authors-file "$AUTHORS_FILE" \
            "${reference_args[@]}"
        then
            echo "ERROR: Label generation failed: $ymd" >&2
            result=1
            continue
        fi

        echo "Generated label candidates:"

        find "$label_dir" \
            -maxdepth 1 \
            -type f \
            -name "*${ymd}*.lblx" \
            -print

    done < <(printf '%s\n' "${!dates[@]}" | sort)

    return "$result"
}

status=0

process_mode \
    "l" \
    "mk_efd_l2_l_e_spin_cdf.sh" \
    || status=1

process_mode \
    "m" \
    "mk_efd_l2_m_e_spin_cdf.sh" \
    || status=1

echo
echo "$0 completed."
date

exit "$status"
