;+
; PROCEDURE: mmo_pwi_efd_calc_e_xsm
;
; PURPOSE: to calculate Ev_x/y and Ev_x/y components of electric field in XSM coordinates.
;
; INPUT:
;   md: sampling frequency (string)
;
; OUTPUT:
;   tplot variables (E-field): 'Eu_x'+md,  'Eu_y'+md', 'Ev_x'+md, and 'Ev_y'+md',
;  
;
;
; Written by: A. Shinbori, Jan 21, 2026
; Modified by:
;   $LastChangedBy:
;   $LastChangedDate:
;   $LastChangedRevision:
;   $URL:
;
;-
pro mmo_pwi_efd_calc_e_xsm, md

  get_data, 'amplitudeX' + md, data = amp_x
  get_data, 'phaseX' + md, data = ph_x
     
  Eu_x = amp_x.y * cos(ph_x.y - 135.0*!dtor)
  Eu_y = amp_x.y * sin(ph_x.y - 135.0*!dtor)

  store_data, 'Eu_x'+md, data={x:amp_x.x, y:Eu_x}
  store_data, 'Eu_y'+md, data={x:amp_x.x, y:Eu_y}
  options, 'Eu_x'+md, ytitle = 'Ex (WPT)', ysubtitle = '[mV/m]'
  options, 'Eu_y'+md, ytitle = 'Ey (WPT)', ysubtitle = '[mV/m]'
  
  get_data, 'amplitudeY'+md, data = amp_y
  get_data, 'phaseY' + md, data = ph_y

  Ev_x = amp_y.y * cos(ph_y.y - (135.0+90.0)*!dtor)
  Ev_y = amp_y.y * sin(ph_y.y - (135.0+90.0)*!dtor)

  store_data, 'Ev_x'+md, data={x:amp_y.x, y:Ev_x}
  store_data, 'Ev_y'+md, data={x:amp_y.x, y:Ev_y}
  options, 'Ev_x'+md, ytitle = 'Ex (MEF)', ysubtitle = '[mV/m]'
  options, 'Ev_y'+md, ytitle = 'Ey (MEF)', ysubtitle = '[mV/m]'

end

