
;+
; PRO efdl1p_to_l2_m_e_spin
;
; :Description:
;    Read EFD L1 prime CDF data and json file and put L1p data value into L2 data.
;
; :Params:
;
; :Keywords:
; outdatadir: Directory in which the CDF data file is saved
; cdfdeffpath: File path of the master CDF table in csv
;
; :Examples:
; IDL> efdl1p_to_l2_m_e_spin, 20181110, cdfi
;
; :History:
; 2024/05/28: Just drafted.
;
; :Author:
; Atsuki Shinbori, ISEE (shinbori at isee.nagoya-u.ac.jp)
;
;-

pro efdl1p_to_l2_m_e_spin, date, cdfi, gitinfo = gitinfo, $
  versionstr=versionstr, l1dat=l1dat, debug = debug

   if ~keyword_set(debug) then debug = 0 ;; For debugging

   if n_params() ne 2 then return

   if ~is_struct(cdfi) then begin
      dprint, 'the given cdfi structure is not a structure!'
      return
   endif

   mmocdf_init

  ;---Load Lv.1 prime data with SPEDAS:
   timespan, string(date), 1
   mmo_load_pwi_efd_l1p, datatype = 'e', level = 'l1p', bitrate = 'm', /get_support_data

  ;---Calculation of 1-sing average E-field:
   mmo_pwi_efd_calc_e_sinfit, '8'

  ;---Calculation of electric field in XSM coordinates from 1-sing average E-field:
   mmo_pwi_efd_calc_e_xsm, '8'

  ;---Check created tplot variables:
   tplot_names

  ;---Get necessary data from tplot variables:
  ;---1-spin averageelectric field data:
   get_data, 'Ex_x8', data = dataXx
   get_data, 'Ey_y8', data = dataYx
   get_data, 'Ex_y8', data = dataXy
   get_data, 'Ey_y8', data = dataYy

   Eu_xsm = fltarr(n_elements(dataXx.x), 2)
   Ev_xsm = fltarr(n_elements(dataXx.x), 2)

   Eu_xsm[*,0] = dataXx.y
   Eu_xsm[*,1] = dataXy.y

   Ev_xsm[*,0] = dataYx.y
   Ev_xsm[*,1] = dataYy.y

  ;---Averaged residual of sine fit:
   get_data, 'residueX8', data = resX
   get_data, 'residueY8', data = resY 

  ;---Offset of sine fit:
   get_data, 'offsetX8', data = offsetX
   get_data, 'offsetY8', data = offsetY

  ;---Phase offset of sine fit:
   get_data, 'phaseX8', data = phaseX
   get_data, 'phaseY8', data = phaseY

  ;---Trend offset of sine fit:
   get_data, 'trendX8', data = trendX
   get_data, 'trendY8', data = trendY

  ;---Quality flag:
   get_data, 'qflag8', data = qflag

  ;---Quality level:
   get_data, 'qlevel8', data = qlevel
   
  ;---time width value::
   get_data, 'time_width_spb', data = time_width_spb

  ;---time width value::
   get_data, 'spinperiod_spb', data = spinperiod_spb

  ;---mdp_ti value::
   get_data, 'mdp_ti_spb', data = mdpti

  ;---Bias value:
   get_data, 'bias18', data = bias1
   get_data, 'bias28', data = bias2
   get_data, 'bias38', data = bias3
   get_data, 'bias48', data = bias4

  ;---Load Lv1 etall data and others
  ;---e.g., data/chs/satellite/mmo/l1sample/pwi/efd/l1/Pot/2018/11/bc_mmo_pwi-efd_l1_l-e_20181110_r01-v00-00.cdf
   if typename(l1dat) ne 'ORDEREDHASH' then begin
     ;---File path of a Lv.1 data
      l1prootdir = '/home/miosc/mio-sc/work_local/data_org/bc/mmo/'  ;;!mmocdf.dat_org_dir
      ts = time_struct( string(date) )
      syyyy = string(ts.year, '(I04)') + '/' ;; 2018/
      syyyymm = string(ts.year, '(I04)') + '/' + string(ts.month, '(I02)') + '/' ;; 2018/11/
      symd = strtrim( string(date), 2 )
      l1pfpath = l1prootdir + 'pwi/efd/l1/' + syyyy + 'bc_mmo_pwi-efd_l1_m-e_'+symd+'_r01-v00-00.cdf'

     ;---Read Lv.1 data and store them in a hash
      if ~file_test( l1pfpath ) then begin
         dprint, 'Cannot find a Lv.1 prime data file!  --> ' + l1fpath
         return
      endif

     ;---CDF ver. 3.8.1 or newer is needed to use cdf_readcdf().
      l1pdat = cdf_readcdf(l1pfpath)
      if typename(l1pdat) ne 'ORDEREDHASH' then begin
         dprint, 'Lv.1 data was not normally stored in an ordered hash!'
         dprint, 'Failed to create a Lv.2 pre CDF file!'
         return
      endif
   endif

  ;---Extract the file name of the source Lv.1 data
   l1pfname = file_basename( l1pdat['CDFInfo','FileName'] )
   src_file_list = [ l1pfname ]


  ;---Get the source code name and rev. number
   get_script_info_git, gitinfo = gitinfo


  ;========Populate g-attributes in a data structure for Lv.2 pre data============

   if debug then dprint, 'Putting g-attrs'

  ;---Name of CDF file
   cdfnm_tmpl = cdfi.filename  ;; bc_mmo_pwi-efd_l2_l-e-spin_YYYYMMDD_rXX-vXX-XX.cdf
   if debug then dprint, 'before :'+cdfnm_tmpl

  ;---Divide a file name template into prefix + the ymd+ver part
   prefix = strmid( cdfnm_tmpl, 0, strpos( cdfnm_tmpl, '_YYYYMMDD' )+1 ) ;; bc_mmo_pwi-efd_l2_l-e-
   ymdver = strmid( cdfnm_tmpl, strpos( cdfnm_tmpl, '_YYYYMMDD' )+1 ) ;; YYYYMMDD_rXX_vXX_XX.cdf

  ;---Combine the prefix and the ymd+ver part whose date string has been replaced with the designated date
   cdfnm_tmpl = prefix + time_string( string(date), tfor=ymdver ) ;; Overwrite YYYYMMDD

  ;---Determing the version number and overwrite rXX_vXX_XX
   if ~undefined(versionstr) then begin
      sverno = versionstr
   endif else sverno = cdfi.g_attributes.data_version ;; r00_v00_00

   cdffn = str_sub( cdfnm_tmpl, 'rXX-vXX-XX', sverno )

  ;---Element in the cdfi structure is overwritten.
   cdfi.filename = cdffn
   if debug then dprint, 'CDF fname finalized: '+ cdffn

  ;---Elements in the PDS_logical_identifier and TITLE are overwritten.
   l1pgatts = l1pdat['GlobalAttrs']
   keys = ['TITLE', 'START_TI', 'END_TI', 'DATA_START_TIME', 'DATA_END_TIME', 'PDS_LOGICAL_IDENTIFIER']
   prefix = 'urn:jaxa:darts:bc_mmo_pwi:data_calibrated_efd:bc-mmo-pwi_cal_sc_efd_l2_m-e-spin_'
   ymdver = strtrim(string(date),2) ;; YYYYMMDD
   
   cdfi.g_attributes.PDS_logical_identifier = prefix + ymdver ;---PDS_logical_identifier
   cdfi.g_attributes.TITLE = cdfi.g_attributes.title ;---TITLE
   cdfi.g_attributes.PDS_COLLECTION_ID = 'urn:jaxa:darts:bc_mmo_pwi:data_calibrated_efd' ;---PDS_COLLECTION_ID
   
   if l1pgatts.haskey('START_TI') then begin
      cdfi.g_attributes.start_ti = ( l1pgatts['START_TI'] )[0]
   end else begin
      cdfi.g_attributes.start_ti = mdpti.y[0]
   endelse
   if l1pgatts.haskey('END_TI') then begin
      cdfi.g_attributes.end_ti = ( l1pgatts['END_TI'] )[0]
   endif else begin
      cdfi.g_attributes.end_ti = mdpti.y[n_elements(mdpti.y)-1]
   endelse

 ;---Start and end time of data
  start_time_str = time_string(dataXx.x[0], tfor = 'YYYY-MM-DDThh:mm:ss.ffffffZ')
  end_time_str = time_string(dataXx.x[-1], tfor = 'YYYY-MM-DDThh:mm:ss.ffffffZ')
  cdfi.g_attributes.data_start_time = start_time_str
  cdfi.g_attributes.data_end_time = end_time_str

 ;---PDS start and end time of data
  cdfi.g_attributes.pds_start_time = start_time_str
  cdfi.g_attributes.pds_stop_time = end_time_str

  ;---Source files and ancillary files
   src_files = strjoin( file_basename(src_file_list), ' ' )
   cdfi.g_attributes.source_file = src_files

  ;---Ancillary file is empty (actually 1 blank space) currently
   anc_files = ' '
   cdfi.g_attributes.ancillary_file = anc_files

  ;---Data version
   cdfi.g_attributes.data_version = sverno

  ;---the Rules of use is unchanged from the on in the data def. table


  ;=======Put calculated data arrays in a data structure for Lv.2 pre data=======

  ;---Variable list:
  ;---epoch strtime time_width mdp_ti

  ;---Put Lv1 data values in the cdfi structure
   if debug then dprint, 'Now putting PWI-EFD L1 prime data in L2 dat structure ...'
   nepoch = n_elements(dataXx.x)
   nepoch_tmp = nepoch

   varnames = cdfi.vars.name

  ;---epoch: long64 [times]
   tst = time_struct(dataXx.x)
   spin_ave_epoch = lon64arr(n_elements(dataXx.x))
   for i=0L, n_elements(tst)-1L do begin
      cdf_tt2000, tt2000_time, tst[i].year, tst[i].month, tst[i].date, tst[i].hour, tst[i].min, tst[i].sec, tst[i].fsec*1000, /compute_epoch
      spin_ave_epoch[i] = tt2000_time
   endfor
   readcdf_var_to_cdfi_var, cdfi, 'epoch', reform(spin_ave_epoch, [1, nepoch]), nepoch

  ;---str_time: string [times]
   strtime = strmid(CDF_ENCODE_TT2000( spin_ave_epoch ), 0, 26) + 'Z' ; epoch time to unix time (string)
   print, strtime[0]
   readcdf_var_to_cdfi_var, cdfi, 'strtime', reform(strtime, [1, nepoch]), nepoch

  ;---PDS SCLK start and end time of data
  ;---Note that currently the SCLK file path is hard-coded here.
   sclk_strs = mmo_utc2sclk([start_time_str, end_time_str],tmp_sclk_fpath='~/work_local/data_org/spice/bc/kernels/sclk/bc_mmo_stre_20250305_v01.tsc',debug=debug, files = files)
   sclk_files = files
   for i = 0, n_elements(sclk_files) -1 do begin
      parts = strsplit(sclk_files[i], '/', /extract)
      filename = parts[-1] 
      if i eq 0 then append_array, cdf_in_sclk_file, filename + ', '
      if i gt 0 and i lt n_elements(sclk_files) - 2 then append_array, cdf_in_sclk_file, filename + ', '
      if i eq n_elements(sclk_files) - 2 then cdf_in_lsk_file = filename
      if i eq n_elements(sclk_files) - 1 then append_array, cdf_in_sclk_file, filename
   endfor
   cdf_in_sclk_file = strjoin(cdf_in_sclk_file, " ")
   
   cdfi.g_attributes.spice_kernels = cdf_in_sclk_file
   cdfi.g_attributes.leapseconds_kernel = cdf_in_lsk_file   
   cdfi.g_attributes.pds_sclk_start_count = sclk_strs[0] + '000'
   cdfi.g_attributes.pds_sclk_stop_count = sclk_strs[1]  + '000'

  ;---mdp_ti: ulong [times]
   readcdf_var_to_cdfi_var, cdfi, 'mdp_ti', reform(mdpti.y, [1, nepoch]), nepoch

  ;---Time width: [times]
   readcdf_var_to_cdfi_var, cdfi, 'time_width', reform( time_width_spb.y, [1, nepoch] ), nepoch

  ;--Electric field data of Ex, Ey, and related values: [times, pts]
   readcdf_var_to_cdfi_var, cdfi, 'Eu_8hz_xsm', reform( Eu_xsm, [1, nepoch, 2] ), nepoch
   readcdf_var_to_cdfi_var, cdfi, 'Ev_8hz_xsm', reform( Ev_xsm, [1, nepoch, 2] ), nepoch
   readcdf_var_to_cdfi_var, cdfi, 'Eu_trend_8hz', reform( trendX.y, [1, nepoch] ), nepoch
   readcdf_var_to_cdfi_var, cdfi, 'Ev_trend_8hz', reform( trendY.y, [1, nepoch] ), nepoch
   readcdf_var_to_cdfi_var, cdfi, 'Eu_phase_8hz', reform( phaseX.y, [1, nepoch] ), nepoch
   readcdf_var_to_cdfi_var, cdfi, 'Ev_phase_8hz', reform( phaseY.y, [1, nepoch] ), nepoch
   readcdf_var_to_cdfi_var, cdfi, 'Eu_offset_8hz', reform( offsetX.y, [1, nepoch] ), nepoch
   readcdf_var_to_cdfi_var, cdfi, 'Ev_offset_8hz', reform( offsetY.y, [1, nepoch] ), nepoch
   readcdf_var_to_cdfi_var, cdfi, 'Eu_residual_8hz', reform( resX.y, [1, nepoch] ), nepoch
   readcdf_var_to_cdfi_var, cdfi, 'Ev_residual_8hz', reform( resY.y, [1, nepoch] ), nepoch

  ;---Spin period: [times, pts]
   readcdf_var_to_cdfi_var, cdfi, 'spinperiod', reform( spinperiod_spb.y, [1, nepoch] ), nepoch

  ;---BIAS level: [times, pts]
   readcdf_var_to_cdfi_var, cdfi, 'BIAS_LVL_U1', reform(bias1.y, [1, nepoch]), nepoch
   readcdf_var_to_cdfi_var, cdfi, 'BIAS_LVL_U2', reform(bias2.y, [1, nepoch]), nepoch
   readcdf_var_to_cdfi_var, cdfi, 'BIAS_LVL_V1', reform(bias3.y, [1, nepoch]), nepoch
   readcdf_var_to_cdfi_var, cdfi, 'BIAS_LVL_V2', reform(bias4.y, [1, nepoch]), nepoch

  ;---Quality flag: [times, pts]
   readcdf_var_to_cdfi_var, cdfi, 'quality_flag', reform(qflag.y, [1, nepoch]), nepoch

  ;---Quality level: [times, pts]
   readcdf_var_to_cdfi_var, cdfi, 'quality_level', reform(qlevel.y, [1, nepoch]), nepoch
   
  if debug then dprint, 'Finished populating the cdfi structure'

  return
end

