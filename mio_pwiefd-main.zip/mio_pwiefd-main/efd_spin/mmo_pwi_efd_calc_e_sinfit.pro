;+
; PROCEDURE: mmo_pwi_efd_calc_e_sinfit
;
; PURPOSE: to calculate spinfit E field data in MMO satellite coordinates
;
; INPUT:
;   date: sampling frequency (string)
;
; OUTPUT:
;   tplot variables (fitted results): 'amplitudeX', 'phaseX', 'offsetX', 'residueX', and 'trendX'
;   tplot variables (related results): 'qflag', 'bias1', 'bias2', 'bias3', and 'bias4'
;   
;
; Written by: A. Shinbori, Jan 21, 2026
; Modified by:
;   $LastChangedBy: 
;   $LastChangedDate: 
;   $LastChangedRevision:
;   $URL:
;   
;-
pro mmo_pwi_efd_calc_e_sinfit, mode

  ;---Initial setting:
   get_timespan, time

   print, time_string(time[0])
   print, time_string(time[1])
   md = mode
   fsamp = fix(mode)

  ;---identify operation mode from sampling frequency:
   if md eq '4' then bitrate = 'l'
   if md eq '8' then bitrate = 'm'
   if md eq '128' then bitrate = 'h'

  ;---Time derivation of spin phase data:
   deriv_data, 'mmo_pwi_efd_l1p_l_e_spinphase_' + md + 'hz'

  ;---Time clip of each data length between start time - 1-spin period and end time + 1-spin period 
   time_clip, 'mmo_pwi_efd_l1p_l_e_quality_flag', time[0] + 86400.d0 - 4.0d, time[1] - 86400.d0 + 4.0d
   time_clip, 'mmo_pwi_efd_l1p_l_e_quality_level', time[0] + 86400.d0 - 4.0d, time[1] - 86400.d0 + 4.0d
   time_clip, 'mmo_pwi_efd_l1p_l_e_mdp_ti', time[0] + 86400.d0 - 4.0d, time[1] - 86400.d0 + 4.0d
   time_clip, 'mmo_pwi_efd_l1p_l_e_BIAS_LVL_U1', time[0] + 86400.d0 - 4.0d, time[1] - 86400.d0 + 4.0d
   time_clip, 'mmo_pwi_efd_l1p_l_e_BIAS_LVL_U2', time[0] + 86400.d0 - 4.0d, time[1] - 86400.d0 + 4.0d
   time_clip, 'mmo_pwi_efd_l1p_l_e_BIAS_LVL_V1', time[0] + 86400.d0 - 4.0d, time[1] - 86400.d0 + 4.0d
   time_clip, 'mmo_pwi_efd_l1p_l_e_BIAS_LVL_V2', time[0] + 86400.d0 - 4.0d, time[1] - 86400.d0 + 4.0d
   time_clip, 'mmo_pwi_efd_l1p_l_e_Eu_' + md + 'hz', time[0] + 86400.d0 - 4.0d, time[1] - 86400.d0 + 4.0d
   time_clip, 'mmo_pwi_efd_l1p_l_e_Ev_' + md + 'hz', time[0] + 86400.d0 - 4.0d, time[1] - 86400.d0 + 4.0d
   time_clip, 'mmo_pwi_efd_l1p_l_e_spinphase_' + md + 'hz', time[0] + 86400.d0 - 4.0d, time[1] - 86400.d0 + 4.0d
   time_clip, 'mmo_pwi_efd_l1p_l_e_spinperiod', time[0] + 86400.d0 - 4.0d, time[1] - 86400.d0 + 4.0d
   time_clip, 'mmo_pwi_efd_l1p_l_e_spinphase_' + md + 'hz_ddt', time[0] + 86400.d0 - 4.0d, time[1] - 86400.d0 + 4.0d
                              
  ;---Get PWI EFD L1p data:
   if strcmp(tnames('mmo_pwi_efd_l1p_l_e_Eu_' + md + 'hz_tclip'), '') then begin
      print, 'Not found E-field tplot variables'
      return
   endif
   
  ;---Get nessesary data from tplot variables: 
   get_data, 'mmo_pwi_efd_l1p_l_e_quality_flag_tclip', data = d_qflag
   get_data, 'mmo_pwi_efd_l1p_l_e_quality_level_tclip', data = d_qlevel   
   get_data, 'mmo_pwi_efd_l1p_l_e_mdp_ti_tclip', data = mdp_ti
   get_data, 'mmo_pwi_efd_l1p_l_e_BIAS_LVL_U1_tclip', data = d_bias1
   get_data, 'mmo_pwi_efd_l1p_l_e_BIAS_LVL_U2_tclip', data = d_bias2
   get_data, 'mmo_pwi_efd_l1p_l_e_BIAS_LVL_V1_tclip', data = d_bias3
   get_data, 'mmo_pwi_efd_l1p_l_e_BIAS_LVL_V2_tclip', data = d_bias4  
   get_data, 'mmo_pwi_efd_l1p_l_e_Eu_' + md + 'hz_tclip', data = dataX
   get_data, 'mmo_pwi_efd_l1p_l_e_Ev_' + md + 'hz_tclip', data = dataY   
   get_data, 'mmo_pwi_efd_l1p_l_e_spinphase_' + md + 'hz_tclip', data = spinphase
   get_data, 'mmo_pwi_efd_l1p_l_e_spinperiod_tclip', data = spinperiod
   get_data, 'mmo_pwi_efd_l1p_l_e_spinphase_' + md + 'hz_ddt_tclip', data = spinphase_dt   
   sptime = spinperiod.x

  ;---Obtain array nummber of dspinphase/dt < 0:
   idx_spinphase_dt_ng = where(spinphase_dt.y lt 0.0, cnt)
    
  ;---Create data format
   ntime = n_elements(spinperiod.x)
   dif_time = 4.5
   m_time = 0.0
   i = 0L
  ;---Loop on calculation of sine fitted E-field:
   for i_idx = 0L, n_elements(idx_spinphase_dt_ng) - 1L do begin
    
     ;---When the i_idx + 1L value is more than the number of spinphase_dt.x array, the calculation stops:  
      if  i_idx + 1L ge n_elements(idx_spinphase_dt_ng) - 1L then break
  
     ;---Calculate time inverval of negative time derivation of spin phase data:
      d_time = spinphase_dt.x[idx_spinphase_dt_ng[i_idx + 1L]] - spinphase_dt.x[idx_spinphase_dt_ng[i_idx + 0L]]
     
     ;---Tjme interval is more than 1.0 sec or not. Yes --> The folling fitting method is done. 
      if d_time ge 3.0d then begin    
  
        ;---Spin period:
         spT  = spinperiod.y[nn(spinperiod.x, spinphase.x[idx_spinphase_dt_ng[i_idx]])]
         
        ;---Start and end time of the data used for sine fit calculation: 
         start_time = spinphase_dt.x[idx_spinphase_dt_ng[i_idx]]
         start_phase = spinphase.y[idx_spinphase_dt_ng[i_idx]]
         end_time = spinphase_dt.x[idx_spinphase_dt_ng[i_idx+1L]]
         end_phase = spinphase.y[idx_spinphase_dt_ng[i_idx+1L]]

        ;---Center time of 1-spin data:         
         t0 = start_time - start_phase * (end_time - start_time) / (end_phase - start_phase)
         fitting_time = t0 + spT/2.0d

        ;---Obtain the array number of start and end times:
         idx_st = value_locate(dataX.x, start_time)
         idx_et = value_locate(dataX.x, end_time)
         idx_init = value_locate(spinperiod.x, end_time)
         ideallen = long((end_time - start_time) * fsamp)
         len = idx_et-idx_st + 1L
         
        ;---Eliminate unavailable data
         bias = d_bias1.y[nn(d_bias1.x, start_time):nn(d_bias1.x, end_time)]
         biasLVL = 0.0 
         biasLVL = max(bias)
         idx1 = (nn(d_qflag.x, start_time))[0]
         idx2 = (nn(d_qflag.x, end_time))[0]
         qflag_idx = array_or(d_qflag.y[idx1:idx2])
         qlevel_idx = array_or(d_qlevel.y[idx1:idx2])

       if i ge 1 then begin
          dif_time = fitting_time - m_time[i-1]
       endif
       if dif_time ge 3.0 then begin
        ;---Central time of data length used in sine fitting and appnd time array: 
         append_array, m_time, fitting_time

        ;---Select mdp_ti and spinperiod data corresponding to each spin start and end times:
         idx_mdpti = (nn(mdp_ti.x, start_time))[0]
         idx_spperiod = (nn(spinperiod.x, start_time))[0]

        ;---Appnd arrays of each parameter: 
         append_array, spmdpti, mdp_ti.y[idx_mdpti]
         append_array, sptime_width, dataX.x[idx_et] - dataX.x[idx_st]
         append_array, spspinperiod, spinperiod.y[idx_spperiod]
         append_array, qflag, array_or(d_qflag.y[idx1:idx2])
         append_array, qlevel, array_or(d_qlevel.y[idx1:idx2])         
         append_array, bias1, mean(d_bias1.y[idx1:idx2],/nan)
         append_array, bias2, mean(d_bias2.y[idx1:idx2],/nan)
         append_array, bias3, mean(d_bias3.y[idx1:idx2],/nan)
         append_array, bias4, mean(d_bias4.y[idx1:idx2],/nan)

        ;---Conduct a sine fitting for Ewpt:
         data_idx = dataX.y[idx_st:idx_et]
         phase_idx = spinphase.y[idx_st:idx_et]
         mmo_pwi_efd_e_sinfit, data_idx, phase_idx, spT, ans, del = del, fit = fit ; Asin(wt-B)+Ct+D
         append_array, amplitudeX, ans.amp
         append_array, phaseX, ans.phase
         append_array, offsetX, ans.offset
         append_array, trendX, ans.trend
         append_array, residueX, ans.residue
         
        ;---Conduct a sine fitting for Emef:
         data_idx = dataY.y[idx_st:idx_et]
         phase_idx = spinphase.y[idx_st:idx_et]
         mmo_pwi_efd_e_sinfit, data_idx, phase_idx, spT, ans, del = del, fit = fit ; Asin(wt-B)+Ct+D
         append_array, amplitudeY, ans.amp
         append_array, phaseY, ans.phase
         append_array, offsetY, ans.offset
         append_array, trendY, ans.trend
         append_array, residueY, ans.residue      

        ;---Print the specific time:
         if ((i_idx mod 450l) eq 0l) then print, time_string(start_time)

        i = i +1L  
        endif
      endif
   endfor

  ;---Store tplot variables:
  ;---Ex data (amplitude, phase, offset, residal, and trend):
   store_data, 'amplitudeX' + md, data={x:m_time, y:amplitudeX}
   store_data, 'phaseX' + md, data = {x:m_time, y:phaseX}
   store_data, 'offsetX' + md, data = {x:m_time, y:offsetX}
   store_data, 'residueX' + md, data = {x:m_time, y:residueX}
   store_data, 'trendX' + md, data = {x:m_time, y:trendX}

  ;---Ey data (amplitude, phase, offset, residal, and trend):
   store_data, 'amplitudeY' + md, data = {x:m_time, y:amplitudeY}
   store_data, 'phaseY' + md, data = {x:m_time, y:phaseY}
   store_data, 'offsetY' + md, data = {x:m_time, y:offsetY}
   store_data, 'residueY' + md, data = {x:m_time, y:residueY}
   store_data, 'trendY' + md, data = {x:m_time, y:trendY}

  ;---Quality flag, quality level, mdp_ti, spinperiod, time width and baias data:
   store_data, 'qflag' + md, data = {x:m_time, y:qflag}
   store_data, 'qlevel' + md, data = {x:m_time, y:qlevel}   
   store_data, 'mdp_ti_spb', data={x:m_time, y:spmdpti}
   store_data, 'spinperiod_spb', data = {x:m_time, y:spspinperiod}
   store_data, 'time_width_spb', data={x:m_time, y:sptime_width}   
   store_data, 'bias1' + md, data = {x:m_time, y:bias1}
   store_data, 'bias2' + md, data = {x:m_time, y:bias2}
   store_data, 'bias3' + md, data = {x:m_time, y:bias3}
   store_data, 'bias4' + md, data = {x:m_time, y:bias4}  

  ;---Time clip of calculated data:
   time_clip, 'amplitudeX' + md, time[0] + 86400.d0, time[1] - 86400.d0, /replace
   time_clip, 'phaseX' + md, time[0] + 86400.d0, time[1] - 86400.d0, /replace
   time_clip, 'offsetX' + md, time[0] + 86400.d0, time[1] - 86400.d0, /replace
   time_clip, 'residueX' + md, time[0] + 86400.d0, time[1] - 86400.d0, /replace
   time_clip, 'trendX' + md, time[0] + 86400.d0, time[1] - 86400.d0, /replace
   time_clip, 'amplitudeY' + md, time[0] + 86400.d0, time[1] - 86400.d0, /replace
   time_clip, 'phaseY' + md, time[0] + 86400.d0, time[1] - 86400.d0, /replace
   time_clip, 'offsetY' + md, time[0] + 86400.d0, time[1] - 86400.d0, /replace
   time_clip, 'residueY' + md, time[0] + 86400.d0, time[1] - 86400.d0, /replace
   time_clip, 'trendY' + md, time[0] + 86400.d0, time[1] - 86400.d0, /replace 
   time_clip, 'qflag' + md, time[0] + 86400.d0, time[1] - 86400.d0, /replace
   time_clip, 'qlevel' + md, time[0] + 86400.d0, time[1] - 86400.d0, /replace   
   time_clip, 'mdp_ti_spb', time[0] + 86400.d0, time[1] - 86400.d0, /replace
   time_clip, 'spinperiod_spb', time[0] + 86400.d0, time[1] - 86400.d0, /replace
   time_clip, 'time_width_spb', time[0] + 86400.d0, time[1] - 86400.d0, /replace   
   time_clip, 'bias1' + md, time[0] + 86400.d0, time[1] - 86400.d0, /replace
   time_clip, 'bias2' + md, time[0] + 86400.d0, time[1] - 86400.d0, /replace
   time_clip, 'bias3' + md, time[0] + 86400.d0, time[1] - 86400.d0, /replace
   time_clip, 'bias4' + md, time[0] + 86400.d0, time[1] - 86400.d0, /replace
         
   ;if (idx_st ne -1) and (idx_et ne -1) and (len ge 0.9*ideallen) then begin


     ;         if (biasLVL ge -100000.0) and (qflag_idx eq 0) then begin


     ;        endif
  ; endif

end

