;+
; PROCEDURE: sinfunc
;
; PURPOSE: to define a sine function used in a fitting method 
;
; INPUT:
;   X = spin phase data (float)
;
; OUTPUT:
;   A: struct value (amplitude, phase, trend, offset, and two amplitudes of sin(2.0*X) and cos(2.0*X))
;   pder = [ [cos( X - A[1] )],  [ A[0] * sin( X - A[1] ) ],  [X], [ sin(2.0*X) ],[ cos(2.0*X) ], [replicate(1.0,n_elements(X))] ]
;
; Written by: A. Shinbori, Jan 21, 2026
; Modified by:
;   $LastChangedBy:
;   $LastChangedDate:
;   $LastChangedRevision:
;   $URL:
;
;-
pro sinfunc, X, A, F, pder

  ;  F=A[0]*sin(X)+A[1]*cos(X)+A[2]
  ;  pder=[[sin(X)], [cos(X)],[replicate(1.0, n_elements(X))]]

  ;ver01
  ; F = A[0] * cos( X - A[1] )  +  A[2] * X  +  A[3] 
  ; pder = [ [cos( X - A[1] )],  [ A[0] * sin( X - A[1] ) ],  [X], [replicate(1.0,n_elements(X))] ]

  ;ver02
   F = A[0] * cos( X - A[1] ) + A[2] * sin( 2.0 * X ) + A[3] * cos( 2.0 * X )+ A[4] * X + A[5]
   pder = [ [cos( X - A[1] )],  [ A[0] * sin( X - A[1] ) ],  [ sin( 2.0 * X ) ], [ cos( 2.0 * X ) ], [X], [replicate(1.0,n_elements(X))] ]


end

;+
; PROCEDURE: mmo_pwi_efd_e_sinfit
;
; PURPOSE: to calculate spinfit E field data in MMO satellite coordinates
;
; INPUT:
;   data = electric field data (float)
;   phase = spin phase data (float)
;   spT = spin period data (float)
;   
; OUTPUT:
;   ans = fitting results (amplitude, phase, residual, and trend)
;   del = Y-yfit_t
;   fit = yfit_t + offset
;
; Written by: A. Shinbori, Jan 21, 2026
; Modified by:
;   $LastChangedBy:
;   $LastChangedDate:
;   $LastChangedRevision:
;   $URL:
;
;-
pro mmo_pwi_efd_e_sinfit, data, phase, spT, ans, del = del, fit = fit

  ;---Remove offet value
   offset = mean(data, /nan)
   Y = data - offset

  ;---Phase data (deg --> rad)
   X = 2.0*!pi * phase / 360.0

  ;---Number of data points:
   nd = float(n_elements(Y))
  
  ;---Weight: 
   weights = replicate(1.0, nd)

  ;Hazure-ti
   idx = where(abs(Y) gt 2.0*stddev(Y))
   if (idx[0] eq 0) then Y[0l]=Y[-1l]
   idx = where(abs(Y) gt 2.0*stddev(Y))
   if (idx[0] ge 1) then Y[idx]=Y[idx-1l]
   idx = where(abs(Y) gt 2.0*stddev(Y))
   if (idx[0] eq 0) then Y[0l]=Y[-1l]
   idx = where(abs(Y) gt 2.0*stddev(Y))
   if (idx[0] ge 1) then Y[idx]=Y[idx-1l]

  ;Initialization
   max_Y = max(Y, Max_phs)
   min_Y = min(Y, Min_phs)

   amp0 = (max_Y - min_Y) / 2.
   phs0 = Max_phs*2.0*!pi/nd
   trd0 = (Y[-1l]-Y[0l])/(2.0*!pi)

   A = [amp0, phs0, amp0, amp0, trd0, 0.] ; amplitude, phase, amp1, amp2, trend, offset

  ;---Conduct a sine fitting (first time):
   yfit_t = curvefit(X, Y, weights, A, sigma, function_name = 'sinfunc', $
                    CHISQ = CHISQ, TOL = 1d-3, ITMAX = 100, STATUS = STATUS)

  ;---Conduct a sine fitting (second time) (CHISQ > 1.0):
   if CHISQ gt 1.0 then begin
      A1 = A
      yfit_t2 = curvefit(X, Y, weights, A1, sigma, function_name = 'sinfunc', $
                        CHISQ = CHISQ2, TOL = 1d-3, ITMAX = 100, STATUS = STATUS2)
      if CHISQ2 lt CHISQ then begin
         A = A1
         STATUS = STATUS2
      endif
   endif

  ;---Replace fitted data by missing value (STAUS is not equal to 1.0):
   if STATUS ne 0 then begin
     ;A[*]=!values.d_nan
     ;yfit_t[*]=!values.d_nan
   endif

  ;---Amplitude should be positive
   if A[0] lt 0.0 then begin
      A[0] = abs(A[0])
      A[1] = A[1] + !pi
   endif
   
  ;---Phase should be in 0 - 2pi
   A[1] = ((A[1] + 100.0 * 2.0*!pi) mod (2.0*!pi))

  ;---Residual value: 
   Y = data - offset
  ;z = sqrt(total((yfit_t-Y)^2)) / (nd*A[0])
   z = sqrt(total((yfit_t-Y)^2)) / nd
   
  ;---Convert the unit
   A[4] = A[4] * 2d0 * !dpi/spT ;[#/s]

  ;---Return variables: 
   ans = { amp: A[0], phase: A[1], trend: A[4], offset: offset + A[5], residue:z}
   del = Y-yfit_t
   fit = yfit_t + offset

  ;IF ((time[0] GT time_double('2019-06-15/03:25:40')) $
  ;AND (time[0] LT time_double('2019-06-15/03:25:45'))) THEN BEGIN
  ;plot, data
  ;oplot, yfit_t+offset, color=220
  ;print, A
  ;stop
  ;ENDIF

end
