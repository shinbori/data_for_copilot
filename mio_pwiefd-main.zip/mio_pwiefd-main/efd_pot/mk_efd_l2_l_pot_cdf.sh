#!/usr/bin/env bash
#
# Usage:
#   mk_efd_l2_l_pot_cdf.sh 20181109
#   mk_efd_l2_l_pot_cdf.sh -v r00-v00-00 20181109
#   mk_efd_l2_l_pot_cdf.sh -v r00-v00-00 20181109 20181110
#

set -u

VERSION=""
OUTCDFDIR="${HOME}/work_local/mmodata/cdf/pwi/efd/l2/l/pot"
EFD_COMMON="${HOME}/work_local/data_pipeline/mmo/pwi/efd/efd_common"

usage()
{
    echo "Usage: $(basename "$0") [-v VERSION] YYYYMMDD [YYYYMMDD ...]"
}

# ----------------------------------------------------------------------
# オプション処理
# ----------------------------------------------------------------------

while getopts ":v:h" opt; do
    case "$opt" in
        v)
            VERSION="$OPTARG"
            ;;
        h)
            usage
            exit 0
            ;;
        :)
            echo "ERROR: Option -$OPTARG requires an argument." >&2
            usage >&2
            exit 2
            ;;
        \?)
            echo "ERROR: Unknown option: -$OPTARG" >&2
            usage >&2
            exit 2
            ;;
    esac
done

shift $((OPTIND - 1))

# ----------------------------------------------------------------------
# 引数確認
# ----------------------------------------------------------------------

if (( $# == 0 )); then
    usage >&2
    exit 2
fi

# ----------------------------------------------------------------------
# IDL環境設定
# ----------------------------------------------------------------------

BASH_PATH="${HOME}/.bash_path"

if [[ ! -r "$BASH_PATH" ]]; then
    echo "ERROR: Environment file is not readable: $BASH_PATH" >&2
    exit 1
fi

# shellcheck source=/dev/null
source "$BASH_PATH"

if [[ ! -d "$EFD_COMMON" ]]; then
    echo "ERROR: IDL source directory not found: $EFD_COMMON" >&2
    exit 1
fi

# IDL_PATHが未定義でもset -uでエラーにならないようにする
export IDL_PATH="+${EFD_COMMON}:${IDL_PATH:-}"

if ! command -v idl >/dev/null 2>&1; then
    echo "ERROR: idl command was not found." >&2
    exit 1
fi

mkdir -p "$OUTCDFDIR" || {
    echo "ERROR: Cannot create output directory: $OUTCDFDIR" >&2
    exit 1
}

# ----------------------------------------------------------------------
# 一時IDLプログラム
# ----------------------------------------------------------------------

TMP_IDLPRO=$(mktemp "${TMPDIR:-/tmp}/efd_l2_l_pot.XXXXXX.pro") || {
    echo "ERROR: Failed to create a temporary file." >&2
    exit 1
}

cleanup()
{
    rm -f "$TMP_IDLPRO"
}

trap cleanup EXIT HUP INT TERM

# ----------------------------------------------------------------------
# CDF生成
# ----------------------------------------------------------------------

for ymd in "$@"; do
    if [[ ! $ymd =~ ^[0-9]{8}$ ]]; then
        echo "ERROR: Invalid date format: $ymd" >&2
        echo "       Use YYYYMMDD, for example 20181109." >&2
        exit 2
    fi

    echo "Processing: $ymd"

    if [[ -n "$VERSION" ]]; then
        version_keyword=", versionstr='${VERSION}'"
    else
        version_keyword=""
    fi

    cat >"$TMP_IDLPRO" <<EOF
makecdf_mmo_pwi_efd_l2_l_pot, ${ymd}${version_keyword}, /debug, outcdfdir='${OUTCDFDIR}/'
exit
EOF

    # デバッグ用
    # cat "$TMP_IDLPRO"

    if ! nice -n 8 idl "$TMP_IDLPRO"; then
        echo "ERROR: IDL processing failed: $ymd" >&2
        exit 1
    fi
done

exit 0
