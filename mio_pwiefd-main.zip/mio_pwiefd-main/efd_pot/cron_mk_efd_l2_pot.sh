#!/usr/bin/env bash
#
# Usage:
#   cron_mk_efd_l2_pot.sh
#   cron_mk_efd_l2_pot.sh all
#

set -u
shopt -s nullglob

# ----------------------------------------------------------------------
# 二重起動防止
# ----------------------------------------------------------------------

LOCKFILE="/tmp/$(basename "$0").lock"

exec 9>"$LOCKFILE"
flock -n 9 || {
    echo "Already running: $0" >&2
    exit 9
}

date

# ----------------------------------------------------------------------
# 共通設定
# ----------------------------------------------------------------------

export PYTHONPATH="${HOME}/work_local/pds_pipeline/common/miopds_common"

WDIR="${HOME}/work_local/data_pipeline/mmo/pwi/efd/efd_pot"
L1_PRIMEPATH="${HOME}/work_local/data_org/bc/mmo/pwi/efd/l1_prime"
L2_BASE="${HOME}/work_local/mmodata/cdf/pwi/efd/l2"

LABEL_GENERATOR_DIR="${HOME}/work_local/data_pipeline/mmo/pwi/efd/pds/label_generator"
TEMPLATEPATH="${TEMPLATEPATH:-$LABEL_GENERATOR_DIR}"
TEMPLATE_NAME="${TEMPLATE_NAME:-mmo_cdf_label_template_multi_dataset.xml.j2}"
TEMPLATE_FILE="${TEMPLATEPATH}/${TEMPLATE_NAME}"
LABEL_GENERATOR="${LABEL_GENERATOR:-${LABEL_GENERATOR_DIR}/make_pds_label_for_mmo_cdf_data.sh}"
PDS_SCIENCE_BASE="${PDS_SCIENCE_BASE:-/var/www/html/data/chs/satellite/mmo/pds4/bc_mmo_pwi/data_calibrated_efd/science}"

# Configure the shared label renderer and instrument-specific author list.
LABEL_PROFILE="${LABEL_PROFILE:-pwi-efd}"
MISSION_PHASE_NAME="${MISSION_PHASE_NAME:-Cruise}"
MISSION_PHASE_ID="${MISSION_PHASE_ID:-cruise}"
AUTHORS_FILE="${AUTHORS_FILE:-${LABEL_GENERATOR_DIR}/authors_pwi_efd.json}"

# Document-product references.
PWI_USER_GUIDE_LIDVID="${PWI_USER_GUIDE_LIDVID:-urn:jaxa:darts:bc_mmo_pwi:document:pwi_data_user_guide::1.0}"
PWI_CALIBRATION_GUIDE_LIDVID="${PWI_CALIBRATION_GUIDE_LIDVID:-urn:jaxa:darts:bc_mmo_pwi:document:pwi_efd_calibration_guide::1.0}"

# SPICE Kernel-product references.
# Set these to registered PSA/PDS4 LIDVID values before archive delivery.
BC_MMO_LSK_LIDVID="${BC_MMO_LSK_LIDVID:-urn:esa:psa:bc_spice:spice_kernels:lsk_naif0012.tls::1.0}"
BC_MMO_SCLK_LIDVID="${BC_MMO_SCLK_LIDVID:-urn:esa:psa:bc_spice:spice_kernels:sclk:bc_mmo_stre_20250305_v01.tsc::1.0}"
BC_MMO_FK_LIDVID="${BC_MMO_FK_LIDVID:-urn:esa:psa:bc_spice:spice_kernels:fk_bc_mmo_v14.tf::1.0}"

# Map the L1p filename version to the PDS VID used by the archived product.
l1_filename_version_to_pds_vid()
{
    local filename_version="$1"

    case "$filename_version" in
        r01-v00-00|r01-v01-00|r02-v01-00)
            printf '%s\n' "1.0"
            ;;
        *)
            echo "ERROR: No PDS VID mapping for L1p version: $filename_version" >&2
            return 1
            ;;
    esac
}

L1_PRIMEVER="r01-v00-00"
L2VER="r01-v00-00"

MIN_DATE="20181001"

cd "$WDIR" || {
    echo "ERROR: Cannot change directory: $WDIR" >&2
    exit 1
}
[[ -x "$LABEL_GENERATOR" ]] || { echo "ERROR: Label generator is not executable: $LABEL_GENERATOR" >&2; exit 1; }
[[ -f "$TEMPLATE_FILE" ]] || { echo "ERROR: Label template not found: $TEMPLATE_FILE" >&2; exit 1; }
[[ -f "$AUTHORS_FILE" ]] || {
    echo "ERROR: Citation authors file was not found: $AUTHORS_FILE" >&2
    exit 1
}

mkdir -p "$PDS_SCIENCE_BASE"

# ----------------------------------------------------------------------
# 引数処理
# ----------------------------------------------------------------------

ALL_UPDATE=0

case "${1:-}" in
    "")
        ;;
    all)
        ALL_UPDATE=1
        ;;
    *)
        echo "Usage: $(basename "$0") [all]" >&2
        exit 2
        ;;
esac

# ----------------------------------------------------------------------
# モード単位の処理
#
# 引数:
#   $1: モード l / m / h
#   $2: CDF生成用シェルスクリプト
# ----------------------------------------------------------------------

process_mode()
{
    local mode="$1"
    local cdf_generator_name="$2"

    local l2_path="${L2_BASE}/${mode}/pot"
    local cdf_generator="${WDIR}/${cdf_generator_name}"

    local input_file
    local input_name
    local ymd
    local yyyy
    local mm

    local cdf_dir
    local cdf_file
    local label_dir
    local pds_cdf
    local pds_cdf
    local label_file

    local result=0
    local reference l1_filename_version l1_pds_vid raw_lidvid
    local -a internal_references=()
    local -a reference_args=()

    # --------------------------------------------------------------
    # 必要なプログラムとテンプレートを確認
    # --------------------------------------------------------------

    if [[ ! -x "$cdf_generator" ]]; then
        echo "ERROR: CDF generator is not executable:" >&2
        echo "       $cdf_generator" >&2
        return 1
    fi

    # nullglobにより、対象がなければ空配列になる
    local -a input_files=(
        "${L1_PRIMEPATH}"/????/bc_mmo_pwi-efd_l1p_"${mode}"-pot_????????_"${L1_PRIMEVER}".cdf
    )

    if (( ${#input_files[@]} == 0 )); then
        echo "No input files found for ${mode^^}-mode."
        return 0
    fi

    echo
    echo "============================================================"
    echo "Processing ${mode^^}-mode POT data"
    echo "============================================================"

    # --------------------------------------------------------------
    # 各入力ファイルを処理
    # --------------------------------------------------------------

    for input_file in "${input_files[@]}"; do
        input_name=${input_file##*/}

        # ファイル名から日付を取得
        ymd=${input_name#bc_mmo_pwi-efd_l1p_${mode}-pot_}
        ymd=${ymd%%_*}

        if [[ ! $ymd =~ ^[0-9]{8}$ ]]; then
            echo "WARNING: Invalid date in filename:" >&2
            echo "         $input_file" >&2
            result=1
            continue
        fi

        # 指定日より前は対象外
        if (( 10#$ymd < 10#$MIN_DATE )); then
            continue
        fi

        # Derive the exact source-product reference from the input filename.
        if [[ "$input_name" =~ _(r[0-9]+-v[0-9]+-[0-9]+)\.cdf$ ]]; then
            l1_filename_version="${BASH_REMATCH[1]}"
        else
            echo "WARNING: Cannot extract the L1p version: $input_file" >&2
            continue
        fi
        l1_pds_vid="$(l1_filename_version_to_pds_vid "$l1_filename_version")" || continue
        raw_lidvid="urn:jaxa:darts:bc_mmo_pwi:data_raw_efd:bc-mmo-pwi_raw_sc_efd_l1p_${mode}-pot_${ymd}::${l1_pds_vid}"
        internal_references=(
            "${PWI_USER_GUIDE_LIDVID}|data_to_document"
            "${PWI_CALIBRATION_GUIDE_LIDVID}|data_to_document"
            "${BC_MMO_LSK_LIDVID}|data_to_spice_kernel"
            "${BC_MMO_SCLK_LIDVID}|data_to_spice_kernel"
            "${BC_MMO_FK_LIDVID}|data_to_spice_kernel"
            "${raw_lidvid}|data_to_raw_product"
        )

        yyyy=${ymd:0:4}
        mm=${ymd:4:2}

        cdf_dir="${l2_path}/${yyyy}/${mm}"
        cdf_file="${cdf_dir}/bc_mmo_pwi-efd_l2_${mode}-pot_${ymd}_${L2VER}.cdf"

        label_dir="${PDS_SCIENCE_BASE}/${yyyy}0101_${yyyy}1231"
        pds_cdf="${label_dir}/$(basename "$cdf_file")"
        label_file="${label_dir}/bc_mmo_pwi-efd_l2_${mode}-pot_${ymd}_${L2VER}.lblx"

        mkdir -p "$cdf_dir" "$label_dir" || {
            echo "ERROR: Failed to create output directories." >&2
            result=1
            continue
        }

        echo
        echo "Processing date: $ymd"

        # ----------------------------------------------------------
        # all指定の場合は既存ファイルを削除
        # ----------------------------------------------------------

        if (( ALL_UPDATE )); then
            if [[ -e "$cdf_file" ]]; then
                echo "allupdate: removing $(basename "$cdf_file")"
                rm -f "$cdf_file"
            fi

            if [[ -e "$label_file" ]]; then
                echo "allupdate: removing $(basename "$label_file")"
                rm -f "$label_file"
            fi
        fi

        # ----------------------------------------------------------
        # Level 2 CDF生成
        # ----------------------------------------------------------

        echo "L1 source file : $input_file"
        echo "L2 target file : $cdf_file"

        if [[ ! -e "$cdf_file" || "$input_file" -nt "$cdf_file" ]]; then
            if ! "$cdf_generator" -v "$L2VER" "$ymd"; then
                echo \
                    "ERROR: CDF generation failed: $ymd (${mode^^}-mode)" \
                    >&2
                result=1
                continue
            fi
        else
            echo "CDF is up to date."
        fi

        # CDF生成結果の確認
        if [[ ! -f "$cdf_file" ]]; then
            echo "ERROR: Expected CDF file was not generated:" >&2
            echo "       $cdf_file" >&2
            result=1
            continue
        fi

        # ----------------------------------------------------------
        # PDSラベル生成
        # ----------------------------------------------------------

        # Copy the generated CDF to the year-specific PDS4 science directory.
        echo "CDF copy source   : $cdf_file"
        echo "CDF copy target   : $pds_cdf"
        if [[ ! -f "$pds_cdf" || "$cdf_file" -nt "$pds_cdf" ]]; then
            if ! cp -fp "$cdf_file" "$pds_cdf"; then
                echo "ERROR: Failed to copy CDF to PDS4 directory: $cdf_file" >&2
                result=1
                continue
            fi
        else
            echo "PDS4 CDF copy is up to date."
        fi
        [[ -f "$pds_cdf" ]] || { echo "ERROR: Copied CDF does not exist: $pds_cdf" >&2; result=1; continue; }
        echo "L2 source file    : $cdf_file"
        echo "Label target file: $label_file"

        if [[ ! -f "$label_file" ||
              "$pds_cdf" -nt "$label_file" ||
              "$TEMPLATE_FILE" -nt "$label_file" ||
              "$AUTHORS_FILE" -nt "$label_file" ||
              "$LABEL_GENERATOR" -nt "$label_file" ||
              "$LABEL_GENERATOR_DIR/render_mmo_cdf_label_multi_dataset.py" -nt "$label_file" ]]; then
            reference_args=()
            for reference in "${internal_references[@]}"; do
                reference_args+=(--internal-reference "$reference")
            done

            if ! "$LABEL_GENERATOR" \
                "$pds_cdf" \
                "$TEMPLATEPATH" \
                "$TEMPLATE_NAME" \
                "$label_dir" \
                --profile "$LABEL_PROFILE" \
                --time-variable strtime \
                --epoch-variable epoch \
                --mission-phase-name "$MISSION_PHASE_NAME" \
                --mission-phase-id "$MISSION_PHASE_ID" \
                --authors-file "$AUTHORS_FILE" \
                "${reference_args[@]}"
            then
                echo "ERROR: Label generation failed: $ymd (${mode^^}-mode)" >&2
                result=1
                continue
            fi
        else
            echo "PDS label is up to date."
        fi

        # ラベル生成結果の確認
        if [[ ! -f "$label_file" ]]; then
            echo "ERROR: Expected label file was not generated:" >&2
            echo "       $label_file" >&2
            result=1
            continue
        fi

        echo "Completed: $ymd (${mode^^}-mode)"
    done

    return "$result"
}

# ----------------------------------------------------------------------
# L-mode
# ----------------------------------------------------------------------

status=0

process_mode \
    "l" \
    "mk_efd_l2_l_pot_cdf.sh" \
    || status=1

# ----------------------------------------------------------------------
# M-mode
# ----------------------------------------------------------------------

process_mode \
    "m" \
    "mk_efd_l2_m_pot_cdf.sh" \
    || status=1

# ----------------------------------------------------------------------
# H-mode
#
# 必要な生成プログラム、Python、テンプレートが存在する場合に有効化
# ----------------------------------------------------------------------

# process_mode \
#     "h" \
#     "mk_efd_l2_h_pot_cdf.sh" \
#     "make_pds_label_pwi_efd_l2_h_pot.py" \
#     "bc_mmo_pwi-efd_l2_h-pot_template.lblx" \
#     || status=1

echo
echo "$0 completed."
date

exit "$status"
