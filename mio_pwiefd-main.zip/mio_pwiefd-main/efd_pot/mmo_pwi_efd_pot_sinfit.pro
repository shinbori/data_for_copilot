;+
; PROCEDURE: sinfunc
;
; PURPOSE: to define a sine function used in a fitting method
;
; INPUT:
;   X = spin phase data (float)
;
; OUTPUT:
;   A: struct value (amplitude, phase, trend, and offset)
;   pder:[sin(X + A[1])], [A[0] * cos(X + A[1])], [replicate(1.0,n_elements(X))]
;
; Written by: A. Shinbori, Jan 21, 2026
; Modified by:
;   $LastChangedBy:
;   $LastChangedDate:
;   $LastChangedRevision:
;   $URL:
;
;-
pro sinfunc, X, A, F, pder

;  F=A[0]*sin(X)+A[1]*cos(X)+A[2]
;  pder=[[sin(X)], [cos(X)],[replicate(1.0, n_elements(X))]]

  F = A[0] * sin(X + A[1]) + A[2]
  pder=[[sin(X + A[1])], [A[0] * cos(X + A[1])], [replicate(1.0,n_elements(X))]]
 
;  F=A[0]*cos(X+A[1])+A[2]
;  pder=[[cos(X+A[1])], [-A[0]*sin(X+A[1])], [replicate(1.0,n_elements(X))]]

end

;+
; PROCEDURE: mmo_pwi_efd_e
; pot_sinfit
;
; PURPOSE: to calculate spinfit potential data
;
; INPUT:
;   data = potential data (float)
;   phase = spin phase data (float)
;   spT = spin period data (float)
;
; OUTPUT:
;   ans = fitting results (amplitude, phase, and offset)
;
; Written by: A. Shinbori, Jan 21, 2026
; Modified by:
;   $LastChangedBy:
;   $LastChangedDate:
;   $LastChangedRevision:
;   $URL:
;
;-
pro mmo_pwi_efd_pot_sinfit, data, phase, spT, ans

  ;---Define array of calculation results:
   ans = fltarr(3)

  ;---Potential data
   Y = data

  ;---Phase data (deg --> rad)
   X = 2.0 * !pi * phase / 360.0

  ;---Number of data points:
   nd = float(n_elements(Y))

  ;---Weight:
   weights = replicate(1.0, nd)

  ;---Initialization    
   a1 = (max(Y)-min(Y))/2.
   a2 = 0.0
   a3 = mean(Y)

  ;---Maximum abd minimum potential values:
   Maxp = where(Y eq max(Y))  
   Minp = where(Y eq max(Y))

  ;---Maxp > Minp:
   if Maxp[0] gt Minp[0] then begin
      a2 = !pi - asin((Y[0] - a3)/max(abs(Y - a3)))
   endif else begin
      a2 = asin((Y[0] - a3)/max(abs(Y - a3)))
   endelse

  ;---Array definition of amplitude, phase, offset:
   A = [a1, a2, a3]                

  ;---Calculation of sine fitted value:
   yfit_t = curvefit(X, Y, weights, A, sigma, function_name='sinfunc', ITMAX=100l)

  ;---Standard deviation
   z = sqrt(total((yfit_t - Y)^2))/(A[0]*nd)

  ;---Fitted results:
   ans = [A,z]


;;;;;  
;     yfit[0:dT-1]=yfit_t
;     ydiff[0:dT-1]=Y-A[2]

;     yfit[*,i]=yfit_t
;     ydiff[*,i]=Y-A[2]

;     nd=n_elements(yfit)
     
;     store_data, 'yfit_'+smpl+'HZ_'+elem, data={x:data.x[0:nd-1],y:yfitAll}
;     store_data, 'ydiff_'+smpl+'HZ_'+elem, data={x:data.x[0:nd-1],y:ydiff}
;     store_data, 'ANS_'+smpl+'Hz_'+elem, data={x:data.x[0:nd-1:len], y:transpose(ans)}

;;;;;;;;;

;  stop

  gt1:
  
  gt0:
;  stop

end
