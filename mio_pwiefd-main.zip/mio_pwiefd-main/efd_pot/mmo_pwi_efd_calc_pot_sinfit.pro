;+
; PROCEDURE: mmo_pwi_efd_calc_pot_sinfit
;
; PURPOSE: to calculate spinfit potential data
;
; INPUT:
;   date: sampling frequency (string)
;
; OUTPUT:
;   tplot variables (fitted results): 'amplitudeX', 'phaseX', 'offsetX', 'residueX', and 'trendX'
;   tplot variables (related results): 'qflag', 'qlevel', 'bias1', 'bias2', 'bias3', and 'bias4'
;
;
; Written by: A. Shinbori, Jan 21, 2026
; Modified by:
;   $LastChangedBy:
;   $LastChangedDate:
;   $LastChangedRevision:
;   $URL:
;
;-
pro mmo_pwi_efd_calc_pot_sinfit, mode

  ;---Initial setting:
   get_timespan, time
   md = mode
   fsamp = fix(mode)

  ;---Get PWI EFD L1p data:
   if strcmp(tnames('mmo_pwi_efd_l1p_l_pot_Vu1_' + md + 'hz'), '') then begin
      print, 'Not found potential tplot variables'
      return
   endif

  ;---Get nessesary data from tplot variables: 
   get_data, 'mmo_pwi_efd_l1p_l_pot_Vu1_'+ md +'hz', data = dataX1
   get_data, 'mmo_pwi_efd_l1p_l_pot_Vu2_'+ md +'hz', data = dataX2
   get_data, 'mmo_pwi_efd_l1p_l_pot_Vv1_'+ md +'hz', data = dataY1
   get_data, 'mmo_pwi_efd_l1p_l_pot_Vv2_'+ md +'hz', data = dataY2
   get_data, 'mmo_pwi_efd_l1p_l_pot_mdp_ti', data = mdp_ti
   get_data, 'mmo_pwi_efd_l1p_l_pot_quality_flag', data = qflag
   get_data, 'mmo_pwi_efd_l1p_l_pot_quality_level', data = qlevel
   get_data, 'mmo_pwi_efd_l1p_l_pot_BIAS_LVL_U1', data = bias1
   get_data, 'mmo_pwi_efd_l1p_l_pot_BIAS_LVL_U2', data = bias2
   get_data, 'mmo_pwi_efd_l1p_l_pot_BIAS_LVL_V1', data = bias3
   get_data, 'mmo_pwi_efd_l1p_l_pot_BIAS_LVL_V2', data = bias4
   if md eq '1' then get_data, 'mmo_pwi_efd_l1p_l_pot_spinphase', data = spinphase ;---For 1hz data     
   if md ne '1' then get_data, 'mmo_pwi_efd_l1p_l_pot_spinphase_' + md + 'hz', data = spinphase ;---For other hz data:
   get_data, 'mmo_pwi_efd_l1p_l_pot_spinperiod', data = spinperiod

   sptime = spinperiod.x

  ;---Create data format
   ntime = n_elements(spinperiod.x)

  ;---Initilizing array number:
   idx_init=(nn(spinperiod.x, time[0]))[0]
   idx = idx_init

  ;---Loop on calculation of sine fitted potential:
   for i_idx = 0L, ntime -2L do begin

     ;---When the idx value is more than the number of spinperiod.x array, the calculation stops:
      if idx ge n_elements(spinperiod.x) then break

     ;---Spin period:
      spT  = spinperiod.y[idx]     
      
     ;---Start and end time of the data used for sine fit calculation:
      start_time = spinperiod.x[idx]
      end_time = double(spT) + start_time
    
     ;---Obtain the array number of start and end times:
      time = dataX1.x
      idx_st = value_locate(time, start_time)
      idx_et = value_locate(time, end_time)
      idx_init = value_locate(spinperiod.x, end_time)    
      ideallen = long((end_time - start_time) * fsamp)
      len = idx_et-idx_st + 1L
     ;---select mdp_ti data corresponding to each spin start time:
      idx_mdpti = (nn(mdp_ti.x, start_time))[0]
      idx_spperiod = (nn(spinperiod.x, start_time))[0]
            
     ;---time index corresponding to each spin start time:
      idx1 = (nn(bias1.x, start_time))[0]
      idx2 = (nn(bias2.x, start_time))[0]
      idx3 = (nn(bias3.x, start_time))[0]
      idx4 = (nn(bias4.x, start_time))[0]
      
      if (idx_st ne -1) and (idx_et ne -1) and (len ge ideallen) then begin 

        ;----Append the arrays of central time, mdp_ti,  and bias data
         append_array, m_time, mean(dataX1.x[idx_st:idx_et],/nan)
         append_array, spmdpti, mdp_ti.y[idx_mdpti]      
         append_array, sptime_width, dataX1.x[idx_et] - dataX1.x[idx_st]
         append_array, spspinperiod, spinperiod.y[idx_spperiod]
         append_array, spbias1, bias1.y[idx1]
         append_array, spbias2, bias2.y[idx2]
         append_array, spbias3, bias3.y[idx3]
         append_array, spbias4, bias4.y[idx4]

        ;----Sine fitting of Vx1 data:         
         phase_idx = spinphase.y[idx_st:idx_et]
         data_idx = dataX1.Y[idx_st:idx_et]
         mmo_pwi_efd_pot_sinfit, data_idx, phase_idx, spT, ans ;, mode='64' ;; Asin(wt+a)+C

        ;----Append the arrays of sine fitted data (amplitude, phase, offset, and residual)
         append_array, amplitudeX1, ans[0,0]
         append_array, phaseX1, ans[1,0]
         append_array, offsetX1, ans[2,0]
         append_array, zansaX1, ans[3,0]

        ;----Sine fitting of Vx2 data: 
         phase_idx = spinphase.y[idx_st:idx_et]
         data_idx = dataX2.Y[idx_st:idx_et]
         mmo_pwi_efd_pot_sinfit, data_idx, phase_idx, spT, ans ;, mode='64' ;; Asin(wt+a)+C ;, mode='64' ;; Asin(wt+a)+C

        ;----Append the arrays of sine fitted data (amplitude, phase, offset, and residual)         
         append_array, amplitudeX2, ans[0,0]
         append_array, phaseX2, ans[1,0]
         append_array, offsetX2, ans[2,0]
         append_array, zansaX2, ans[3,0]

        ;----Sine fitting of Vy1 data: 
         phase_idx = spinphase.y[idx_st:idx_et]
         data_idx = dataY1.Y[idx_st:idx_et]
         mmo_pwi_efd_pot_sinfit, data_idx, phase_idx, spT, ans ;, mode='64' ;; Asin(wt+a)+C ;, mode='64' ;; Asin(wt+a)+C

        ;----Append the arrays of sine fitted data (amplitude, phase, offset, and residual) 
         append_array, amplitudeY1, ans[0,0]
         append_array, phaseY1, ans[1,0]
         append_array, offsetY1, ans[2,0]
         append_array, zansaY1, ans[3,0]

        ;----Sine fitting of Vy2 data: 
         phase_idx = spinphase.y[idx_st:idx_et]
         data_idx = dataY2.Y[idx_st:idx_et]
         mmo_pwi_efd_pot_sinfit, data_idx, phase_idx, spT, ans ;, mode='64' ;; Asin(wt+a)+C ;, mode='64' ;; Asin(wt+a)+C

        ;----Append the arrays of sine fitted data (amplitude, phase, offset, and residual) 
         append_array, amplitudeY2, ans[0,0]
         append_array, phaseY2, ans[1,0]
         append_array, offsetY2, ans[2,0]
         append_array, zansaY2, ans[3,0]

        ;----Append array of quality flg and level data:
         idx_st=value_locate(qflag.x,start_time)
         idx_et=value_locate(qflag.x,end_time)
         append_array, spqflag, array_or(qflag.y[idx_st:idx_et])

         idx_st=value_locate(qlevel.x,start_time)
         idx_et=value_locate(qlevel.x,end_time)
         append_array, spqlevel, array_or(qlevel.y[idx_st:idx_et])
      endif

      if ((end_time-time[0L])/(60d0*60d0) mod 1d0)-((start_time-time[0L])/(60d0*60d0) mod 1d0) le 0d0 then print, time_string(end_time)

     ;---Next spin phase index:
      idx = idx_init + 1L  

   endfor

  ;---Store tplot variables (amplitude, phase, offset, and residual)
  ;---Vwpt_1 data:
   store_data, 'amplitudeX1', data={x:m_time, y:amplitudeX1}
   store_data, 'phaseX1', data={x:m_time, y:phaseX1}
   store_data, 'offsetX1', data={x:m_time, y:offsetX1}
   store_data, 'zansaX1', data={x:m_time, y:zansaX1}

  ;---Vmef_1 data:
   store_data, 'amplitudeY1', data={x:m_time, y:amplitudeY1}
   store_data, 'phaseY1', data={x:m_time, y:phaseY1}
   store_data, 'offsetY1', data={x:m_time, y:offsetY1}
   store_data, 'zansaY1', data={x:m_time, y:zansaY1}

  ;---Vwpt_2 data:
   store_data, 'amplitudeX2', data={x:m_time, y:amplitudeX2}
   store_data, 'phaseX2', data={x:m_time, y:phaseX2}
   store_data, 'offsetX2', data={x:m_time, y:offsetX2}
   store_data, 'zansaX2', data={x:m_time, y:zansaX2}

  ;---Vmef_2 data:
   store_data, 'amplitudeY2', data={x:m_time, y:amplitudeY2}
   store_data, 'phaseY2', data={x:m_time, y:phaseY2}
   store_data, 'offsetY2', data={x:m_time, y:offsetY2}
   store_data, 'zansaY2', data={x:m_time, y:zansaY2}

  ;---Average value (amplitude, phase, and offset)
   store_data, 'amplitude_ave', data={x:m_time, y:(amplitudeX1 + amplitudeX2 + amplitudeY1 + amplitudeY2)/4.}
   store_data, 'phase_ave', data={x:m_time, y:(phaseX1 + phaseX2 + phaseY1 + phaseY2)/4.}
   store_data, 'offset_ave', data={x:m_time, y:(offsetX1 + offsetX2 + offsetY1 + offsetY2)/4.}
  
  ;---Quality flag, level, mdp_ti, and baias data:
   store_data, 'qflag_spb', data={x:m_time, y:spqflag}
   store_data, 'qlevel_spb', data={x:m_time, y:spqlevel}   
   store_data, 'mdp_ti_spb', data={x:m_time, y:spmdpti}
   store_data, 'spinperiod_spb', data = {x:m_time, y:spspinperiod}
   store_data, 'time_width_spb', data={x:m_time, y:sptime_width}
   store_data, 'bias1', data={x:m_time, y:spbias1}
   store_data, 'bias2', data={x:m_time, y:spbias2}
   store_data, 'bias3', data={x:m_time, y:spbias3}
   store_data, 'bias4', data={x:m_time, y:spbias4}

end






