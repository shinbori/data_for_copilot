#!/usr/bin/env bash

set -u
shopt -s nullglob

LOCKFILE="/tmp/$(basename "$0").lock"
exec 9>"$LOCKFILE"
flock -n 9 || {
    echo "Already running: $0" >&2
    exit 9
}

date

export PYTHONPATH="${HOME}/work_local/pds_pipeline/common/miopds_common${PYTHONPATH:+:$PYTHONPATH}"

WDIR="${HOME}/work_local/data_pipeline/mmo/pwi/efd/efd_spec"
L1_PRIMEPATH="${HOME}/work_local/data_org/bc/mmo/pwi/efd/l1_prime"
L2_BASE="${HOME}/work_local/mmodata/cdf/pwi/efd/l2"

LABEL_GENERATOR_DIR="${HOME}/work_local/data_pipeline/mmo/pwi/efd/pds/label_generator"
TEMPLATEPATH="${TEMPLATEPATH:-$LABEL_GENERATOR_DIR}"
TEMPLATE_NAME="${TEMPLATE_NAME:-mmo_cdf_label_template_multi_dataset.xml.j2}"
TEMPLATE_FILE="${TEMPLATEPATH}/${TEMPLATE_NAME}"

LABEL_GENERATOR="${LABEL_GENERATOR:-${LABEL_GENERATOR_DIR}/make_pds_label_for_mmo_cdf_data.sh}"

PDS_SCIENCE_BASE="${PDS_SCIENCE_BASE:-/var/www/html/data/chs/satellite/mmo/pds4/bc_mmo_pwi/data_calibrated_efd/science}"

LABEL_PROFILE="${LABEL_PROFILE:-pwi-efd}"
MISSION_PHASE_NAME="${MISSION_PHASE_NAME:-Cruise}"
MISSION_PHASE_ID="${MISSION_PHASE_ID:-cruise}"

# Select the structured citation-author file for this instrument.
AUTHORS_FILE="${AUTHORS_FILE:-${LABEL_GENERATOR_DIR}/authors_pwi_efd.json}"


# Document-product references.
PWI_USER_GUIDE_LIDVID="${PWI_USER_GUIDE_LIDVID:-urn:jaxa:darts:bc_mmo_pwi:document:pwi_data_user_guide::1.0}"
PWI_CALIBRATION_GUIDE_LIDVID="${PWI_CALIBRATION_GUIDE_LIDVID:-urn:jaxa:darts:bc_mmo_pwi:document:pwi_efd_calibration_guide::1.0}"

# SPICE Kernel-product references.
# Set these to registered PSA/PDS4 LIDVID values before archive delivery.
BC_MMO_LSK_LIDVID="${BC_MMO_LSK_LIDVID:-urn:esa:psa:bc_spice:spice_kernels:lsk_naif0012.tls::1.0}"
BC_MMO_SCLK_LIDVID="${BC_MMO_SCLK_LIDVID:-urn:esa:psa:bc_spice:spice_kernels:sclk:bc_mmo_stre_20250305_v01.tsc::1.0}"
BC_MMO_FK_LIDVID="${BC_MMO_FK_LIDVID:-urn:esa:psa:bc_spice:spice_kernels:fk_bc_mmo_v14.tf::1.0}"

# The raw L1p data reference is generated inside PROCESS_MODE from the exact
# input filename used for each L2 product. Do not define it as a fixed value.

# Map the L1p filename version to the PDS VID used by the archived L1p product.
l1_filename_version_to_pds_vid()
{
    local filename_version="$1"

    case "$filename_version" in
        r01-v00-00|r01-v01-00|r02-v01-00)
            printf '%s\n' "1.0"
            ;;
        *)
            echo \
                "ERROR: No PDS VID mapping for L1p version: $filename_version" \
                >&2
            return 1
            ;;
    esac
}

L1_PRIMEVER="${L1_PRIMEVER:-r01-v00-00}"
L2VER="r01-v00-00"
MIN_DATE="20181001"

cd "$WDIR" || {
    echo "ERROR: Cannot change directory: $WDIR" >&2
    exit 1
}

[[ -x "$LABEL_GENERATOR" ]] || {
    echo \
        "ERROR: Label generator is not executable: $LABEL_GENERATOR" \
        >&2
    exit 1
}

[[ -f "$TEMPLATE_FILE" ]] || {
    echo "ERROR: Label template not found: $TEMPLATE_FILE" >&2
    exit 1
}

[[ -f "$AUTHORS_FILE" ]] || {
    echo "ERROR: Citation authors file was not found: $AUTHORS_FILE" >&2
    exit 1
}

mkdir -p "$PDS_SCIENCE_BASE"

ALL_UPDATE=0
[[ ${1:-} == "all" ]] && ALL_UPDATE=1

echo "L1p version filter: $L1_PRIMEVER"
echo "L2 output version : $L2VER"

process_mode()
{
    local mode="$1"
    local l2_path="${L2_BASE}/${mode}/spec"
    local mk_script="${WDIR}/mk_efd_l2_${mode}-spec_cdf.sh"

    local input_file input_name ymd yyyy mm
    local year_dir pds_science_dir
    local source_cdf pds_cdf pds_label
    local reference
    local l1_filename_version l1_pds_vid pwi_data_raw_efd_lidvid
    local pds_cdf_changed label_update_required

    local -a input_files=(
        "${L1_PRIMEPATH}"/????/bc_mmo_pwi-efd_l1p_"${mode}"-spec_????????_"${L1_PRIMEVER}".cdf
    )

    if (( ${#input_files[@]} == 0 )); then
        echo "ERROR: No L1p input files found for ${mode}-mode." >&2
        echo "L1p version   : $L1_PRIMEVER" >&2
        echo "Search pattern: ${L1_PRIMEPATH}/????/bc_mmo_pwi-efd_l1p_${mode}-spec_????????_${L1_PRIMEVER}.cdf" >&2
        return 1
    fi

    local -a internal_references=()
    local -a reference_args=()

    [[ -x "$mk_script" ]] || {
        echo \
            "ERROR: CDF generation script is not executable: $mk_script" \
            >&2
        return 1
    }

    echo "Processing ${mode}-mode..."

    for input_file in "${input_files[@]}"; do
        input_name=${input_file##*/}

        if [[ "$input_name" =~ ^bc_mmo_pwi-efd_l1p_([lm])-spec_([0-9]{8})_(r[0-9]+-v[0-9]+-[0-9]+)\.cdf$ ]]; then
            [[ "${BASH_REMATCH[1]}" == "$mode" ]] || continue
            ymd="${BASH_REMATCH[2]}"
            l1_filename_version="${BASH_REMATCH[3]}"
        else
            echo "WARNING: Unsupported L1p filename: $input_file" >&2
            continue
        fi

        [[ "$l1_filename_version" == "$L1_PRIMEVER" ]] || continue
        (( 10#$ymd < 10#$MIN_DATE )) && continue

        l1_pds_vid="$(l1_filename_version_to_pds_vid "$l1_filename_version")" || continue
        pwi_data_raw_efd_lidvid="urn:jaxa:darts:bc_mmo_pwi:data_raw_efd:bc-mmo-pwi_raw_sc_efd_l1p_${mode}-spec_${ymd}::${l1_pds_vid}"

        internal_references=(
            "${PWI_USER_GUIDE_LIDVID}|data_to_document"
            "${PWI_CALIBRATION_GUIDE_LIDVID}|data_to_document"
            "${BC_MMO_LSK_LIDVID}|data_to_spice_kernel"
            "${BC_MMO_SCLK_LIDVID}|data_to_spice_kernel"
            "${BC_MMO_FK_LIDVID}|data_to_spice_kernel"
            "${pwi_data_raw_efd_lidvid}|data_to_raw_product"
        )

        yyyy=${ymd:0:4}
        mm=${ymd:4:2}
        year_dir="${yyyy}0101_${yyyy}1231"

        pds_science_dir="${PDS_SCIENCE_BASE}/${year_dir}"

        source_cdf="${l2_path}/${yyyy}/${mm}/bc_mmo_pwi-efd_l2_${mode}-spec_${ymd}_${L2VER}.cdf"

        pds_cdf="${pds_science_dir}/$(basename "$source_cdf")"
        pds_label="${pds_science_dir}/$(basename "${source_cdf%.cdf}").lblx"

        mkdir -p \
            "$(dirname "$source_cdf")" \
            "$pds_science_dir"

        if (( ALL_UPDATE )); then
            rm -f \
                "$source_cdf" \
                "$pds_cdf" \
                "$pds_label"
        fi

        if [[ ! -e "$source_cdf" ||
              "$input_file" -nt "$source_cdf" ]]; then
            "$mk_script" -v "$L2VER" "$ymd" || {
                echo \
                    "ERROR: CDF generation failed: $ymd (${mode}-mode)" \
                    >&2
                continue
            }
        fi

        # Synchronize the generated L2 CDF and label with the PDS4 tree.
        pds_cdf_changed=0
        label_update_required=0

        if [[ ! -f "$source_cdf" ]]; then
            echo "WARNING: L2 CDF does not exist: $source_cdf" >&2

            if [[ -e "$pds_cdf" ]]; then
                echo "Removing stale PDS CDF: $pds_cdf"
                rm -f "$pds_cdf"
            fi

            if [[ -e "$pds_label" ]]; then
                echo "Removing stale PDS label: $pds_label"
                rm -f "$pds_label"
            fi

            continue
        fi

        # Compare file contents, not only mtimes. This catches updates whose
        # timestamps were preserved during copy or generation.
        if [[ ! -f "$pds_cdf" ]]; then
            echo "PDS CDF does not exist. Copying the L2 CDF."
            pds_cdf_changed=1
        elif ! cmp -s "$source_cdf" "$pds_cdf"; then
            echo "L2 CDF content changed. Updating the PDS CDF."
            pds_cdf_changed=1
        else
            echo "PDS CDF content is up to date."
        fi

        if (( pds_cdf_changed )); then
            cp -fp "$source_cdf" "$pds_cdf" || {
                echo "ERROR: Failed to copy CDF: $source_cdf" >&2
                continue
            }
            label_update_required=1
        fi

        [[ -f "$pds_cdf" ]] || {
            echo "ERROR: PDS CDF does not exist after synchronization: $pds_cdf" >&2
            continue
        }

        # Regenerate the label when its CDF or label-generation inputs changed.
        if [[ ! -f "$pds_label" ]]; then
            label_update_required=1
        elif (( pds_cdf_changed )); then
            label_update_required=1
        elif [[ "$pds_cdf" -nt "$pds_label" ]]; then
            label_update_required=1
        elif [[ "$TEMPLATE_FILE" -nt "$pds_label" ]]; then
            label_update_required=1
        elif [[ "$LABEL_GENERATOR" -nt "$pds_label" ]]; then
            label_update_required=1
        elif [[ -f "$LABEL_GENERATOR_DIR/render_mmo_cdf_label_multi_dataset.py" &&
                "$LABEL_GENERATOR_DIR/render_mmo_cdf_label_multi_dataset.py" -nt "$pds_label" ]]; then
            label_update_required=1
        fi

        if (( label_update_required )); then

            reference_args=()

            for reference in "${internal_references[@]}"; do
                [[ -n "$reference" ]] || continue

                reference_args+=(
                    --internal-reference
                    "$reference"
                )
            done

            echo "L1p source         : $input_file"
            echo "L1p filename ver.  : $l1_filename_version"
            echo "L1p PDS VID        : $l1_pds_vid"
            echo "L1p data reference : $pwi_data_raw_efd_lidvid"
            echo "Internal references:"

            for reference in "${internal_references[@]}"; do
                echo "  $reference"
            done

            "$LABEL_GENERATOR" \
                "$pds_cdf" \
                "$TEMPLATEPATH" \
                "$TEMPLATE_NAME" \
                "$pds_science_dir" \
                --profile "$LABEL_PROFILE" \
                --time-variable strtime \
                --epoch-variable epoch \
                --mission-phase-name "$MISSION_PHASE_NAME" \
                --mission-phase-id "$MISSION_PHASE_ID" \
                --authors-file "$AUTHORS_FILE" \
                "${reference_args[@]}" || {
                    echo \
                        "ERROR: Label generation failed: $ymd (${mode}-mode)" \
                        >&2
                    continue
                }
        else
            echo "PDS label is up to date."
        fi

        [[ -f "$pds_label" ]] || {
            echo "ERROR: Label does not exist: $pds_label" >&2
            continue
        }

        echo "Completed: $ymd (${mode}-mode)"
        echo
    done
}

process_mode "l"
process_mode "m"

echo
echo "$0 completed."
date
