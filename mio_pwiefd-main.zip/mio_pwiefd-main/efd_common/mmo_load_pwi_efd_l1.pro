;+
; PRO mmo_load_pwi_efd_l1
;
; The read program for Level-1 PWI/EFD data
; This program can run on IDL 8.0 or later version.
;
; :Keywords:
;   level: level of data products. Currently only 'l1' is acceptable.
;   datatype: types of data products. 'E_spin', 'pot', 'spec' are
;   acceptable.
;   varformat: If set a string with wildcards, only variables with
;              matching names are extrancted as tplot variables.
;   get_suuport_data: Set to load support data in CDF data files.
;   trange: Set a time range to load data explicitly for the specified
;           time range.
;   downloadonly: If set, data files are downloaded and the program
;                exits without generating tplot variables.
;   no_download: Set to prevent the program from searching in the
;                remote server for data files.
;   verbose:  Set to make some commands in this program verbose.
;   uname: user ID to be passed to the remote server for
;          authentication.
;   passwd: password to be passed to the remote server for
;           authentication.
;   band_width: return the band width of the variable "spectra".
;   ror: If set a string, rules of the road (RoR) for data products
;        are displayed at your terminal.
;
; :Examples:
;   MMO> timespan, '2018-11-19'
;   MMO> mmo_load_pwi_efd_l1
;   MMO> mmo_load_pwi_efd_l1, datatype='E_spin'
;   MMO> mmo_load_pwi_efd_l1, datatype='spec', band_width=band_width
;
; :Authors:
;   Atsuki Shinbori, Mio Science Center (E-mail: shinbori at isee.nagoya-u.ac.jp)
;
; $LastChangedDate: 2019-03-17 21:51:57 -0700 (Sun, 17 Mar 2019) $
; $LastChangedRevision: 26838 $
; https://ergsc-local.isee.nagoya-u.ac.jp/svn/ergsc/trunk/erg/satellite/erg/pwe/erg_load_pwe_efd.pro $
;-



pro mmo_load_pwi_efd_l1, $
  datatype = datatype, coord = coord, level = level, bitrate = bitrate,  $
  downloadonly = downloadonly, $
  no_download = no_download, $
  get_support_data = get_support_data, $
  verbose = verbose, $
  uname = uname, $
  passwd = passwd, $
  band_width = band_width, $
  ror = ror, $
  _extra = _extra

  ;---Initialize mmo environment:
   mmo_init

  ;---Check keywords:
   if ~keyword_set(downloadonly) then downloadonly = 0
   if ~keyword_set(no_download) then begin
      no_download = 0
     ;     if ~keyword_set(uname) then begin
     ;        uname=''
     ;        read, uname, prompt='Enter username: '
     ;     endif
     ;
     ;     if ~keyword_set(passwd) then begin
     ;        passwd=''
     ;        read, passwd, prompt='Enter passwd: '
     ;     endif
   endif


   if ~keyword_set(datatype) then datatype = 'E'
   if ~keyword_set(bitrate) then bitrate = 'L'
   
   case level of

      'l1': begin
         Lvl = 'L1'
         prefix = 'bc_mmo_pwi-efd_l1_'
      end

      'l2': begin
         Lvl = 'L2'
         prefix = 'bc_mmo_pwi-efd_l2_'
      end

      'l3': begin
         Lvl = 'L3'
         prefix = 'bc_mmo_pwi-efd_l3_'
      end

      else: begin
         dprint, 'Incorrect keyword setting: level'
         return
      end

   endcase

   case datatype of
      'E': begin
         md = 'E'
         if bitrate eq 'L' then begin
            component = ['Eu_waveform_4hz','Ev_waveform_4hz']
         endif
         labels = ['Eu', 'Ev']
         coord = ''
      end
      'spin': begin
         md = 'E_spin'
         component = ['Eu','Ev','Eu1','Ev1','Eu2','Ev2']
         labels = ['Ex', 'Ey']
         coord = ''
      end
      'spec': begin
         md = 'Spec'
         coord = ''
      end
      'pot': begin
         md = 'Pot'
         coord = ''
         component = ['Vu1','Vu2','Vv1','Vv2']
         if bitrate eq 'L' then begin
            component = component+'_waveform_1Hz
         endif
      end
      else: begin
         dprint, 'Incorrect keyword setting: datatype'
         return
      end

   endcase

  ;---Prefix of tplot variables:
   prefix = prefix + md + '_' + bitrate + '_'

  ;---Set local and remote directories:
   localdir = '~/work_local/data_org/bc/mmo/pwi/efd/' + level + '/' 
   remotedir = !mmo.remote_data_dir + 'pwi/efd/' + level + '/'; + md + '/'

  ;---Set local and remote directories:     
   yyyy_dir = file_dailynames(file_format = 'YYYY/', trange = trange, times = times, /unique) 
   filepaths = prefix + file_dailynames(file_format = 'YYYYMMDD', trange = trange, times = times, /unique) + '_r??-v??-??.cdf'
   relfpaths = yyyy_dir + filepaths

  ;---Download data files:
   files = spd_download(remote_file = relfpaths, remote_path = remotedir, local_path = localdir, no_download = no_download,$
                       _extra = source, authentication = 2, url_username = uname, url_password = passwd, /last_version)

  ;---File check:
   print, files
   fileslist = file_test(files)

  ;---Filelist check:
   if(total(fileslist) ge 1) then begin
      datfiles = files[where(fileslist eq 1)]
   endif else begin
      print, 'No file is loaded.'
      return
   endelse

  ;---Read downloaded cdf files:
   if keyword_set(downloadonly) then return
   cdf2tplot, file = datfiles, prefix = prefix, get_support_data = get_support_data

  ;---For spinfitted electric field data:
   if strcmp(md,'E_spin') then begin
      foreach elem, component do $
         options, prefix + elem + '_dsi', labels = labels, ytitle = elem + ' vector in DSI', constant = 0
      goto, gt0
   endif

  ;---For potential data:
   if strcmp(md,'Pot') then begin
      foreach elem, component do $
    ;  options, prefix + elem, labels = labels, ytitle = elem + ' potential', constan = 0

     ;---Set y axis:
      ylim, prefix + 'Pot_*',-5,5
      
      options, prefix + 'Pot_Vu1_waveform_1HZ', ytitle = 'PWI/EFD Pot. (Vu1)!CLv.1', ysubtitle = '[V]'
      options, prefix + 'Pot_Vv1_waveform_1HZ', ytitle = 'PWI/EFD Pot. (Vv1)!CLv.1', ysubtitle = '[V]'
      options, prefix + 'Pot_Vu2_waveform_1HZ', ytitle = 'PWI/EFD Pot. (Vu2)!CLv.1', ysubtitle = '[V]'
      options, prefix + 'Pot_Vv2_waveform_1HZ', ytitle = 'PWI/EFD Pot. (Vv2)!CLv.1', ysubtitle = '[V]'
      
      goto, gt0
   endif

  ;---For spectral data:
   if strcmp(md,'Spec') then begin
      cdfi = cdf_load_vars(datfiles, varformat = varformat, var_type = 'support_data', /spdf_depend, $
                          varnames = varnames2, verbose = verbose, record = record, convert_int1_to_int2 = convert_int1_to_int2, all = all)
      idx_bw = where(strmatch(cdfi.vars.name, 'band_width_*') eq 1)
      band_width = *cdfi.vars[idx_bw].dataptr

     ;---Set y and z axies:
      ylim, prefix + 'Spec_*',0,40
      zlim, prefix + 'Spec_*', 1e-4, 1e-1, 1
 
      options, prefix +'Spec_Eu_spectra_ave', ytitle = 'PWI/EFD Eu ave!CLv.1', ysubtitle = 'frequency [Hz]', ztitle = '[mV^2/m^2/Hz]', ylog = 0, /zlog
      options, prefix +'Spec_Ev_spectra_ave', ytitle = 'PWI/EFD Ev ave!CLv.1', ysubtitle = 'frequency [Hz]', ztitle = '[mV^2/m^2/Hz]', ylog = 0, /zlog
      options, prefix +'Spec_Eu_spectra_peak', ytitle = 'PWI/EFD Eu peak!CLv.1', ysubtitle = 'frequency [Hz]', ztitle = '[mV^2/m^2/Hz]', ylog = 0, /zlog
      options, prefix +'Spec_Ev_spectra_peak', ytitle = 'PWI/EFD Ev peak!CLv.1', ysubtitle = 'frequency [Hz]', ztitle = '[mV^2/m^2/Hz]', ylog = 0, /zlog
            
      goto, gt0

   endif

  ;---For other data:
   foreach elem, component do begin

      get_data, prefix + elem, data = data, dlim = dlim

      time1 = data.x
      dt = data.v                    ;time offsets
      delta = time1[1] - time1[0]
      nt = n_elements(time1)

      ndt = n_elements(dt)

      ndata = nt * ndt

      time_new = dblarr(ndata)
      data_new = fltarr(ndata)

      for i = 0, nt - 1 do begin
         time_new[ndt*i:ndt*(i+1)-1] = time1[i] + dt[*] * 1e-3
      endfor
      data_new = reform(transpose(data.y), ndata)

      store_data, prefix + elem, data = {x:time_new, y:data_new}, dlim = dlim

      options, prefix + 'Eu_waveform_4HZ', ytitle = 'PWI/EFD Eu waveform!CLv.1', ysubtitle = '[mV/m]'
      options, prefix + 'Ev_waveform_4HZ', ytitle = 'PWI/EFD Ev waveform!CLv.1', ysubtitle = '[mV/m]'

      ylim, prefix + '*',-20,20

   end

   gt0:

  ;storing data information
  ;erg_export_filever, datfiles

  ; view RoR on terminal
   gatt=cdf_var_atts(datfiles[0])

   print_str_maxlet, ' '
   print, '**********************************************************************'
   print_str_maxlet, gatt.LOGICAL_SOURCE_DESCRIPTION, 80
   print, ''
   print, 'Information about MMO PWI EFD'
   print, ''
   print, 'PI: ', gatt.PI_NAME
   print_str_maxlet, 'Affiliation: '+gatt.PI_AFFILIATION, 80
   print, ''

   if keyword_set(ror) then begin
      print, 'Rules of the Road for MMO PWI EFD Use:'
      for igatt=0, n_elements(gatt.RULES_OF_USE)-1 do print_str_maxlet, gatt.RULES_OF_USE[igatt], 80
         print, ''
         print, gatt.LINK_TEXT, ' ', gatt.HTTP_LINK
   endif else begin
      print, 'RoR of MMO project common: https://miosc.isee.nagoya-u.ac.jp/data/mio.php'
      print, 'RoR of PWI/EFD: https://miosc.isee.nagoya-u.ac.jp/data/mio.php'
      print, 'To show the RoR, set "ror" keyword'
      print, 'Contact: mmo_pwi_info at isee.nagoya-u.ac.jp'
   endelse

   print, '**********************************************************************'

end
